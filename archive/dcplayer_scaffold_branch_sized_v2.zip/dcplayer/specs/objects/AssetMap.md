# AssetMap

## Назначение

Каноническая модель `ASSETMAP` как входной таблицы активов DCP. Это первый объектный контракт для ingest/verify и для `T01a`.

## Канонические поля

- `asset_map_id` — UUID строка
- `issuer` — строка
- `issue_date_utc` — UTC ISO-8601
- `creator` — строка или `null`
- `volume_count` — целое >= 1
- `assets` — массив записей asset

### Asset entry

- `asset_id` — UUID строка
- `chunk_list` — массив chunk entries
- `packing_list_hint` — bool
- `is_text_xml` — bool

### Chunk entry

- `path` — относительный POSIX-style путь
- `offset` — целое >= 0
- `length` — целое > 0
- `volume_index` — целое >= 1

## Инварианты

- `asset_map_id` уникален в пределах пакета.
- Каждый `asset_id` уникален в пределах `assets`.
- Каждый asset имеет как минимум один chunk.
- Все `path` нормализованы, относительны и не выходят выше корня ingest (`..` запрещён).
- Внутри одного asset сочетание `volume_index + path + offset` не должно дублироваться.
- `chunk_list` сериализуется в исходном порядке носителей; сортировка “для красоты” запрещена.

## Namespace и версия

- Парсер обязан фиксировать `namespace_uri` и `schema_flavor` (`interop` / `smpte` / `unknown`).
- Неизвестный namespace не запрещает ingest автоматически, но даёт детерминированный warning-class diagnostic.

## Политика диагностики

Каждая ошибка должна иметь форму:
- `code` — стабильный строковый код
- `severity` — `error` / `warning`
- `path` — JSON pointer или XPath-like location
- `message` — человекочитаемое описание

Минимальные коды для `T01a`:
- `assetmap.missing_required_field`
- `assetmap.invalid_uuid`
- `assetmap.invalid_time`
- `assetmap.duplicate_asset_id`
- `assetmap.invalid_relative_path`
- `assetmap.empty_chunk_list`
- `assetmap.unsupported_namespace`

## Связи с другими объектами

- Используется парсером `T01a`.
- Сопоставляется с `PKL` и `CPL`.
- Формирует вход в `CompositionGraph`.

## Каноническая сериализация

- JSON `snake_case`.
- UUID всегда lower-case canonical form.
- Пути сериализуются как относительные POSIX-style строки без завершающего `/`.
- Диагностика сортируется детерминированно по `severity`, затем по `code`, затем по `path`.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления `docs/PLAN.md`, `docs/STATUS.md` и связанных task-specific `AGENTS.md`.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
