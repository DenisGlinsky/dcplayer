# PKL

## Назначение

Каноническая модель Packing List / `PKL` для состава пакета, control-plane verify и контрольных сумм. Это второй ключевой контракт для `T01a`.

## Канонические поля

- `pkl_id` — UUID строка
- `annotation_text` — строка или `null`
- `issuer` — строка
- `creator` — строка или `null`
- `issue_date_utc` — UTC ISO-8601
- `namespace_uri` — строка
- `schema_flavor` — enum
- `assets` — массив asset entries

### Asset entry

- `asset_id` — UUID строка
- `annotation_text` — строка или `null`
- `asset_type` — enum
- `original_filename` — строка или `null`
- `size_bytes` — целое > 0
- `hash` — digest entry

### Digest entry

- `algorithm` — enum `sha1 | sha256 | unknown`
- `value` — hex/base64 строка как в исходном XML
- `normalized_hex` — lower-case hex строка или `null`

## Инварианты

- Каждый `asset_id` в `assets` уникален.
- Каждая запись asset обязана содержать digest.
- `size_bytes` должен быть положительным.
- Для известных алгоритмов должен существовать нормализованный digest.
- Ссылки на отсутствующие assets из `AssetMap` дают validation error.

## Namespace и версия

- Парсер обязан фиксировать `namespace_uri` и `schema_flavor` (`interop` / `smpte` / `unknown`).
- Неизвестный namespace допускается только как диагностируемое состояние, а не как silent fallback.

## Политика диагностики

Каждая ошибка должна иметь форму:
- `code`
- `severity`
- `path`
- `message`

Минимальные коды для `T01a`:
- `pkl.missing_required_field`
- `pkl.invalid_uuid`
- `pkl.invalid_time`
- `pkl.duplicate_asset_id`
- `pkl.invalid_digest_algorithm`
- `pkl.invalid_digest_value`
- `pkl.asset_missing_in_assetmap`
- `pkl.unsupported_namespace`

## Связи с другими объектами

- Сопоставляется с `AssetMap` и `CPL`.
- Используется `dcp_probe` и `ingest verify`.
- Входит в `CompositionGraph`.

## Каноническая сериализация

- JSON `snake_case`.
- `digest_algorithm` и `digest_value` сериализуются явно.
- Диагностика сортируется детерминированно по `severity`, затем по `code`, затем по `path`.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления `docs/PLAN.md`, `docs/STATUS.md` и связанных task-specific `AGENTS.md`.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
