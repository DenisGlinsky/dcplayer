# WatermarkState

## Назначение

Состояние backend-а forensic watermark во время self-test и runtime.

## Канонические поля

- `backend_id` — строка
- `enabled` — bool
- `policy_mode` — строка
- `last_self_test_result` — enum
- `failure_reason` — строка или null

## Инварианты

- При enabled=false причина должна быть объяснима operator-facing state.

## Связи с другими объектами

- Используется secure playback integration и operator alerts.

## Каноническая сериализация

- JSON snake_case.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления docs/PLAN.md, docs/STATUS.md и связанных task-specific AGENTS.md.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
