# J2KBackendContract

## Назначение

Стабильный контракт backend-а JPEG2000 decode.

## Канонические поля

- `backend_id` — строка
- `backend_class` — enum
- `memory_domain` — enum
- `supported_profiles` — массив строк
- `fallback_backend_id` — строка или null

## Инварианты

- Каждый production backend имеет fallback path.
- Контракт не протекает в доменную модель.

## Связи с другими объектами

- Используется T05a–T05d и secure playback integration.

## Каноническая сериализация

- JSON snake_case.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления docs/PLAN.md, docs/STATUS.md и связанных task-specific AGENTS.md.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
