# TrustChain

## Назначение

Результат проверки цепочки доверия и revocation status.

## Канонические поля

- `subject_fingerprint` — hex строка
- `issuer_chain` — массив fingerprint-ов
- `validation_time_utc` — UTC ISO-8601
- `revocation_status` — enum
- `decision` — enum

## Инварианты

- Цепочка начинается с subject и заканчивается доверенным root либо explicit failure.
- Время проверки обязательно.

## Связи с другими объектами

- Потребляется mutual-TLS contract и KDM validation.

## Каноническая сериализация

- JSON snake_case.
- Статусы сериализуются строковыми enum.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления docs/PLAN.md, docs/STATUS.md и связанных task-specific AGENTS.md.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
