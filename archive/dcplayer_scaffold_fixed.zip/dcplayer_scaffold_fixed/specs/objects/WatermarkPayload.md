# WatermarkPayload

## Назначение

Канонический payload forensic watermark.

## Канонические поля

- `payload_id` — UUID строка
- `session_id` — UUID строка
- `site_code` — строка
- `screen_code` — строка
- `time_slice` — строка или номер окна
- `format_version` — строка

## Инварианты

- Payload version обязателен.
- Payload не должен зависеть от конкретного backend implementation.

## Связи с другими объектами

- Используется watermark backends и detector harness.

## Каноническая сериализация

- JSON snake_case.

## Причины отклонения / ошибки

- отсутствует обязательное поле;
- нарушен инвариант;
- формат времени, enum или идентификатора невалиден;
- объект противоречит связанным контрактам;
- сериализация недетерминирована.

## Замечания по эволюции

- Обратимо-совместимые расширения добавляются новыми полями.
- Ломающие изменения требуют явного обновления docs/PLAN.md, docs/STATUS.md и связанных task-specific AGENTS.md.
- При изменении security semantics нужно дополнительно проверить trust boundary и audit model.
