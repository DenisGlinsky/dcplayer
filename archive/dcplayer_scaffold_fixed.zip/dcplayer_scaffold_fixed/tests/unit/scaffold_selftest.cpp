#include "version.hpp"

#include <iostream>
#include <string>

int main() {
    if (dcplayer::core::project_name() != "dcplayer") {
        std::cerr << "unexpected project name\n";
        return 1;
    }

    const std::string banner = dcplayer::core::make_banner("selftest");
    if (banner.find("dcplayer") == std::string::npos) {
        std::cerr << "banner does not contain project name\n";
        return 2;
    }

    if (banner.find("scaffold") == std::string::npos) {
        std::cerr << "banner does not contain scaffold marker\n";
        return 3;
    }

    return 0;
}
