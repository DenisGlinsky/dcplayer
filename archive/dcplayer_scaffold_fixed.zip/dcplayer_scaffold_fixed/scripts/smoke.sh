#!/usr/bin/env bash
set -euo pipefail

./scripts/bootstrap.sh

build_preset="build-dev-make"
test_preset="test-dev-make"
if command -v ninja >/dev/null 2>&1; then
  build_preset="build-dev-ninja"
  test_preset="test-dev-ninja"
fi

cmake --build --preset "${build_preset}"
ctest --preset "${test_preset}"

./build/bin/dcp_probe --help >/dev/null
./build/bin/playout_service --help >/dev/null
./build/bin/sms_ui --help >/dev/null
./build/bin/tms_web --help >/dev/null

echo "Smoke checks passed"
