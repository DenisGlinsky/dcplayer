#!/usr/bin/env bash
set -euo pipefail

if ! command -v cmake >/dev/null 2>&1; then
  echo "cmake not found" >&2
  exit 1
fi

configure_preset="dev-make"
build_preset="build-dev-make"
test_preset="test-dev-make"
expected_generator="Unix Makefiles"

if command -v ninja >/dev/null 2>&1; then
  configure_preset="dev-ninja"
  build_preset="build-dev-ninja"
  test_preset="test-dev-ninja"
  expected_generator="Ninja"
fi

if [ -f build/CMakeCache.txt ]; then
  current_generator="$(grep '^CMAKE_GENERATOR:INTERNAL=' build/CMakeCache.txt | cut -d'=' -f2- || true)"
  if [ -n "${current_generator}" ] && [ "${current_generator}" != "${expected_generator}" ]; then
    echo "Existing build/ uses '${current_generator}', expected '${expected_generator}'. Cleaning build/."
    rm -rf build
  fi
fi

cmake --preset "${configure_preset}"

echo "Configured build/ using preset '${configure_preset}'."
echo "Next commands:"
echo "  cmake --build --preset ${build_preset}"
echo "  ctest --preset ${test_preset}"
