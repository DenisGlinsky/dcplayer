# dcplayer

Программный DCP player для кинотеатрального программно-аппаратного комплекса.

Корневой путь проекта: `/Users/admin/Documents/dcplayer`

## Текущая цель

Собрать theater-grade DCP playback appliance с Linux-first MVP, поддержкой:
- Interop и SMPTE DCP;
- open и encrypted DCP;
- secure control plane через Raspberry Pi + ZymKey + RTC и Ubuntu + TPM 2.0;
- pipeline `local storage -> HSM decrypt service -> GPU decode -> GPU picture FM -> playout`;
- software forensic picture & sound watermark;
- supplemental / OV / VF;
- subtitles;
- internal PCM engine и последующим AES3 output;
- минимальным SMS/TMS.

## Что уже сделано

На текущем этапе подготовлены:
- базовая структура репозитория;
- проектные правила для Codex;
- архитектурные документы;
- план задач;
- формальные companion-спецификации объектов;
- локальная конфигурация `.codex/config.toml`.

Код плеера ещё не написан: это осознанный этап freeze-документации и task framing.

## Архитектурная выжимка

### Secure show mode

```text
DCP ingest
  -> verify
  -> local storage
  -> show authorization
  -> HSM decrypt service (Raspberry Pi + ZymKey + RTC)
  -> GPU JPEG2000 decode
  -> GPU picture forensic watermark
  -> subtitle composite / output stage
  -> projector / protected output

audio:
  local storage
  -> secure show authorization
  -> decrypt
  -> audio forensic watermark
  -> PCM engine
  -> later AES3 output
```

### Control plane

```text
Ubuntu media server + TPM 2.0  <== mutual TLS ==>  Raspberry Pi + ZymKey
        client cert in TPM                            server cert in ZymKey
```

## Ключевые документы

- `AGENTS.md` — глобальные правила работы Codex.
- `docs/ARCHITECTURE.md` — архитектура системы и trust boundaries.
- `docs/CODE_STYLE.md` — стиль кода и инженерные соглашения.
- `docs/IMPLEMENT.md` — правила реализации, тестирования и отчётности.
- `docs/LIBRARIES.md` — набор библиотек и их статус.
- `docs/PLAN.md` — дорожная карта и task sequence.
- `docs/STATUS.md` — текущий статус проекта.
- `specs/objects/` — формальные companion-спецификации доменных объектов.
- `tasks/` — отдельные task-specific AGENTS для Codex.

## Каркас каталогов

```text
apps/        пользовательские приложения и сервисы
src/         ядро доменной логики, playout, security, audio/video
spb1/        secure module API / simulator / firmware / diagnostics
docs/        архитектурная и проектная документация
specs/       companion-спецификации объектов
tasks/       task-specific инструкции для Codex
tests/       unit / integration / compliance fixtures
scripts/     локальные команды bootstrap/format/smoke
```

## Команды первого запуска

```bash
./scripts/bootstrap.sh
cmake --build build -j
ctest --test-dir build --output-on-failure
```

## Правило по watermark

В этом проекте watermark делается как **pluggable internal subsystem**.
Это означает, что backend внедрения/детекции можно заменить, не переписывая playout graph, security policy и object contracts.
Подробности — в `AGENTS.md` и `docs/IMPLEMENT.md`.

## Ближайшая инженерная последовательность

1. T00 — Security boundary + bootstrap.
2. T01 — DCP probe + composition graph.
3. T02 — OV/VF/supplemental resolver.
4. T03 — mTLS HSM control plane.
5. T04 — KDM/certificate store/show authorization.
6. T05 — watermark backend API + detector harness.
7. T06 — open playback path.
8. T07 — secure playback path.
9. T08 — AES3 + SMS/TMS minimum.
