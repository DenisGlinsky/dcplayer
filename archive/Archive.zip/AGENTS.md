# AGENTS.md

Репозиторий: `/Users/admin/Documents/dcplayer`

Этот проект ведётся по модели "архитектурный штаб + Codex-исполнитель".
Архитекторы фиксируют целевую архитектуру, границы MVP, task cards, companion-спецификации и критерии приёмки.
Codex делает узкие вертикальные срезы, не выходит за рамки задачи и отчитывается по фиксированному шаблону.

## Что обязательно прочитать перед любой правкой

1. `README.md`
2. `docs/ARCHITECTURE.md`
3. `docs/CODE_STYLE.md`
4. `docs/IMPLEMENT.md`
5. `docs/LIBRARIES.md`
6. `docs/PLAN.md`
7. `docs/STATUS.md`
8. `specs/objects/README.md`
9. `tasks/<TASK-ID>/AGENTS.md` для текущей задачи

## Нефальсифицируемые архитектурные правила

1. Secure-mode pipeline фиксирован так:
   `local storage -> HSM decrypt service (Raspberry Pi + ZymKey + RTC) -> GPU decode -> GPU picture FM -> playout`.
   Для audio действует тот же secure show context: audio decrypt -> audio FM -> output.
2. Управляющая плоскость между media server и HSM-модулем строится на mutual-TLS:
   - Raspberry Pi + ZymKey = TLS server;
   - Ubuntu media server + TPM 2.0 = TLS client;
   - клиентский приватный ключ хранится в TPM;
   - серверный приватный ключ хранится в ZymKey;
   - проверка цепочки, CRL/OCSP, журналирование и RBAC обязательны.
3. Никакие реальные приватные ключи, KDM, сертификаты, escrow-материалы и production secrets не коммитятся в репозиторий.
4. Любой performance path обязан иметь fallback path.
5. В cinema-critical коде приоритет такой:
   `детерминизм и корректность -> отказоустойчивость -> производительность`.
6. Никаких заявлений "DCI compliant" в коде, документации или commit message без отдельной матрицы соответствия и набора пройденных испытаний.

## Что значит "pluggable forensic watermark"

Под **pluggable forensic watermark** в этом проекте понимается не маркетплейс внешних плагинов и не произвольная подгрузка чужого кода во время показа.
Это внутренний стабилизированный контракт, за которым можно менять конкретную реализацию алгоритма или ускорителя без изменения остального графа playout.

Минимально это означает:

- единый интерфейс `IForensicMarkingBackend`;
- единый формат payload/metadata/control;
- несколько backend-вариантов:
  - CPU reference backend;
  - GPU production backend;
  - lab backend для исследований;
  - detector harness для извлечения и валидации;
- единый self-test и attack-matrix для всех backend-реализаций;
- одинаковые state machine, telemetry и security policy независимо от выбранного backend.

Иными словами, меняется **внутренний движок внедрения/детекции**, но не меняются:
- show control;
- объектные контракты;
- security log semantics;
- поведение SMS/TMS;
- правила валидации.

## Глобальные правила работы Codex

- Одна задача = один вертикальный срез.
- В каждой задаче обязательно есть цель, non-goals, ограничения, список файлов/модулей, DoD и тесты.
- Никаких тихих рефакторингов за пределами текущей задачи.
- Никаких новых зависимостей без явного отражения в `docs/LIBRARIES.md`.
- Любое изменение формата объекта требует обновления companion-спецификаций в `specs/objects/`.
- Любое изменение trust boundary требует ADR.
- Сначала симулятор/фикстуры, потом работа с реальным железом.
- Никаких фоновых обещаний "потом доделаю". Отчёт — только за реально сделанное.

## Обязательный формат отчёта Codex

Используй шаблон `docs/templates/CODEX_REPORT.md`.

Каждый отчёт обязан содержать:
- что сделано;
- какие файлы изменены;
- чем проверено;
- что не покрыто;
- какие риски остались;
- какие зависимости/лицензии изменились.

## Разрешённая область изменений

Можно менять только:
- `apps/**`
- `src/**`
- `spb1/**`
- `docs/**`
- `specs/**`
- `tests/**`
- `scripts/**`
- `CMakeLists.txt`
- `README.md`
- `AGENTS.md`
- `.clang-format`
- `.clang-tidy`
- `.codex/config.toml`

Нельзя коммитить:
- `*.pem`, `*.key`, `*.p12`, `*.pfx`, `*.csr`, `*.crt`
- реальные KDM/сертификаты
- дампы plaintext essence
- core dumps и логи с чувствительными данными

## Базовые команды

```bash
./scripts/bootstrap.sh
cmake --build build -j
ctest --test-dir build --output-on-failure
./scripts/format.sh
./scripts/smoke.sh
```

## Перед сдачей задачи

1. Перечитай task-specific `AGENTS.md`.
2. Проверь, что изменения не выходят за scope.
3. Обнови связанные companion-спецификации.
4. Обнови `docs/STATUS.md`, если поменялся статус проекта.
5. Подготовь отчёт строго по шаблону.
