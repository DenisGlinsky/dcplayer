# CompositionGraph

Статус: draft
Версия: 0.1

## Назначение

Итоговый нормализованный граф композиции, на который опираются диагностика и playout.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `graph_id` | `string` | yes | Идентификатор graph build. |
| `asset_map_id` | `string` | no | Связь с AssetMap. |
| `packing_list_ids` | `array<string>` | no | PKL, участвующие в graph. |
| `cpl_id` | `string` | yes | Главный CPL. |
| `reels` | `array<Reel>` | yes | Нормализованные reel. |
| `track_files` | `array<TrackFile>` | yes | Все track files, используемые графом. |
| `supplemental_bindings` | `array<SupplementalBinding>` | no | OV/VF bindings. |
| `diagnostics` | `array<object>` | no | Машиночитаемые предупреждения и ошибки. |
| `status` | `string(enum)` | yes | ok/warning/error. |

## Инварианты

1. cpl_id обязателен;
2. каждый TrackResource должен резолвиться в track_files либо сопровождаться диагностикой;
3. status=ok допускается только при отсутствии ошибок уровня error.

## Связи с другими объектами

- Собирается из AssetMap, PackingList, CompositionPlaylist, SupplementalBinding.

## Каноническая сериализация (JSON)

```json
{
  "graph_id": "graph-001",
  "cpl_id": "urn:uuid:...",
  "reels": [],
  "track_files": [],
  "status": "ok"
}
```

## Причины отклонения / ошибки

- `missing_cpl`
- `unresolved_track_reference`
- `supplemental_conflict`

## Замечания по эволюции

- Именно этот объект является базой для CLI JSON output и будущего playout plan.
