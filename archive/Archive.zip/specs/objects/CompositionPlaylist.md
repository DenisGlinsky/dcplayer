# CompositionPlaylist

Статус: draft
Версия: 0.1

## Назначение

Каноническое представление CPL.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `cpl_id` | `string` | yes | Идентификатор CPL. |
| `content_title_text` | `string` | no | Название контента. |
| `content_kind` | `string` | no | Kind: feature/trailer/test/etc. |
| `annotation_text` | `string` | no | Аннотация. |
| `issuer` | `string` | no | Issuer metadata. |
| `creator` | `string` | no | Creator metadata. |
| `issue_date_utc` | `string(datetime)` | no | Время выпуска CPL. |
| `edit_rate` | `string` | yes | Каноническая форма `num den`. |
| `is_encrypted` | `boolean` | yes | Есть ли зашифрованные track resources. |
| `reels` | `array<Reel>` | yes | Порядок reel в композиции. |

## Инварианты

1. reels упорядочены по позиции показа;
2. edit_rate обязателен даже если внутри ресурсов встречаются локальные значения;
3. cpl_id уникален в пределах package analysis session.

## Связи с другими объектами

- Содержит Reel и через них TrackResource связи к TrackFile/AssetRef.

## Каноническая сериализация (JSON)

```json
{
  "cpl_id": "urn:uuid:...",
  "content_title_text": "FEATURE_FTR-1_S_EN-XX",
  "edit_rate": "24 1",
  "is_encrypted": true,
  "reels": []
}
```

## Причины отклонения / ошибки

- `missing_cpl_id`
- `missing_reels`
- `invalid_edit_rate`

## Замечания по эволюции

- Наличие encrypted tracks вычисляется по ресурсам, но фиксируется на уровне объекта для быстрых policy checks.
