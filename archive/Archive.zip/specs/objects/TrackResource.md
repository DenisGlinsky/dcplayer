# TrackResource

Статус: draft
Версия: 0.1

## Назначение

Использование TrackFile внутри reel.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `resource_id` | `string` | yes | Идентификатор resource. |
| `track_file_id` | `string` | yes | Ссылка на TrackFile. |
| `resource_kind` | `string(enum)` | yes | picture/sound/subtitle/timed_text/aux. |
| `edit_rate` | `string` | yes | Edit rate ресурса. |
| `entry_point` | `integer` | no | Начало в исходном essence. |
| `source_duration` | `integer` | yes | Длительность участка. |
| `repeat_count` | `integer` | no | Повтор ресурса. |
| `key_id` | `string` | no | Локальный override/echo ключа. |
| `language` | `string` | no | Язык ресурса, если есть. |

## Инварианты

1. source_duration > 0;
2. edit_rate обязателен;
3. repeat_count, если задан, должен быть >= 1.

## Связи с другими объектами

- Принадлежит Reel и указывает на TrackFile.

## Каноническая сериализация (JSON)

```json
{
  "resource_id": "res-1",
  "track_file_id": "urn:uuid:...",
  "resource_kind": "picture",
  "edit_rate": "24 1",
  "source_duration": 1728
}
```

## Причины отклонения / ошибки

- `missing_track_file_id`
- `invalid_source_duration`
- `invalid_repeat_count`

## Замечания по эволюции

- Resource — это playout use-site, а не сам файл.
