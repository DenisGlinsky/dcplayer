# SupplementalBinding

Статус: draft
Версия: 0.1

## Назначение

Связка OV/VF/supplemental ресурсов.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `binding_id` | `string` | yes | Идентификатор binding. |
| `vf_cpl_id` | `string` | yes | CPL варианта/дополнения. |
| `ov_cpl_id` | `string` | yes | Базовый CPL. |
| `resolved_assets` | `array<string>` | no | Список asset/track ids, взятых из OV. |
| `vf_overrides` | `array<string>` | no | Список asset/track ids, которые переопределены VF. |
| `missing_assets` | `array<string>` | no | Отсутствующие зависимости. |
| `binding_status` | `string(enum)` | yes | ok/warning/error. |

## Инварианты

1. vf_cpl_id и ov_cpl_id обязательны;
2. binding_status=ok возможен только при пустом missing_assets;
3. один и тот же track id не должен одновременно быть и resolved_asset, и vf_override без явного конфликта.

## Связи с другими объектами

- Используется CompositionGraph resolver.

## Каноническая сериализация (JSON)

```json
{
  "binding_id": "bind-1",
  "vf_cpl_id": "urn:uuid:vf",
  "ov_cpl_id": "urn:uuid:ov",
  "binding_status": "ok"
}
```

## Причины отклонения / ошибки

- `missing_ov_reference`
- `missing_vf_reference`
- `binding_conflict`

## Замечания по эволюции

- Модель deliberately simple: сложные случаи выражаются через diagnostics.
