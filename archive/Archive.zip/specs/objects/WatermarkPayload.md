# WatermarkPayload

Статус: draft
Версия: 0.1

## Назначение

Канонический payload/control объект для picture/audio forensic marking.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `payload_id` | `string` | yes | Идентификатор payload. |
| `scheme_id` | `string` | yes | Идентификатор схемы/алгоритма. |
| `show_instance_id` | `string` | yes | Идентификатор показа или аудитории. |
| `screen_id` | `string` | yes | Идентификатор зала/экрана. |
| `time_window` | `object` | yes | Окно применимости payload. |
| `picture_payload` | `object` | no | Данные для picture marking. |
| `audio_payload` | `object` | no | Данные для audio marking. |
| `generation` | `integer` | yes | Версия/поколение payload. |
| `integrity_tag` | `string` | no | Тег целостности/control checksum. |

## Инварианты

1. должен присутствовать хотя бы один из picture_payload/audio_payload;
2. time_window обязателен;
3. generation >= 1.

## Связи с другими объектами

- Используется watermark backend, PlaybackSession и SecurityLogEvent.

## Каноническая сериализация (JSON)

```json
{
  "payload_id": "wm-1",
  "scheme_id": "wm-scheme-v1",
  "show_instance_id": "show-42",
  "screen_id": "screen-1",
  "time_window": { "start_utc": "2026-03-10T10:00:00Z", "end_utc": "2026-03-10T12:30:00Z" },
  "picture_payload": { "seed": "..." },
  "audio_payload": { "seed": "..." },
  "generation": 1
}
```

## Причины отклонения / ошибки

- `missing_mark_payload`
- `invalid_time_window`
- `invalid_generation`

## Замечания по эволюции

- Этот объект не раскрывает секретную внутреннюю математику watermark algorithm.
