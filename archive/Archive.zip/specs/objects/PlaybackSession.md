# PlaybackSession

Статус: draft
Версия: 0.1

## Назначение

Каноническое состояние показа/проигрывания композиции.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `playback_session_id` | `string` | yes | Идентификатор показа. |
| `cpl_id` | `string` | yes | Идентификатор композиции. |
| `show_schedule_id` | `string` | no | Связь с расписанием. |
| `mode` | `string(enum)` | yes | open/secure. |
| `state` | `string(enum)` | yes | created/authorized/buffering/playing/stopped/failed/completed. |
| `security_module_session_id` | `string` | no | Связь с SecurityModuleSession для secure mode. |
| `selected_picture_backend` | `string` | no | Выбранный decode backend. |
| `selected_audio_backend` | `string` | no | Выбранный audio backend. |
| `selected_watermark_backend` | `string` | no | Выбранный marking backend. |
| `authorized_window_start_utc` | `string(datetime)` | no | Начало окна авторизации. |
| `authorized_window_end_utc` | `string(datetime)` | no | Конец окна авторизации. |
| `started_at_utc` | `string(datetime)` | no | Фактический старт. |
| `stopped_at_utc` | `string(datetime)` | no | Фактическая остановка. |

## Инварианты

1. cpl_id обязателен;
2. mode=secure требует security_module_session_id при state>=authorized;
3. state progression должна быть монотонной, кроме явных fail/stop transitions.

## Связи с другими объектами

- Используется playout orchestration, SMS/TMS и security logging.

## Каноническая сериализация (JSON)

```json
{
  "playback_session_id": "play-1",
  "cpl_id": "urn:uuid:...",
  "mode": "secure",
  "state": "playing",
  "security_module_session_id": "sess-1",
  "selected_picture_backend": "cuda_nvjpeg2000",
  "selected_watermark_backend": "gpu_reference_v1"
}
```

## Причины отклонения / ошибки

- `missing_cpl_id`
- `secure_without_security_session`
- `invalid_playback_transition`

## Замечания по эволюции

- PlaybackSession — operational объект; он не заменяет подробный playout plan.
