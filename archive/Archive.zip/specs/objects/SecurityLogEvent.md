# SecurityLogEvent

Статус: draft
Версия: 0.1

## Назначение

Нормализованное событие security logging.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `event_id` | `string` | yes | Идентификатор события. |
| `sequence_no` | `integer` | yes | Монотонный номер события. |
| `event_time_utc` | `string(datetime)` | yes | Время события. |
| `event_type` | `string` | yes | Тип события. |
| `severity` | `string(enum)` | yes | info/warning/error/critical. |
| `device_id` | `string` | no | Устройство-источник. |
| `session_id` | `string` | no | Связь с SecurityModuleSession или PlaybackSession. |
| `show_id` | `string` | no | Связь с показом. |
| `result` | `string(enum)` | yes | success/denied/failed/unknown. |
| `details_redacted` | `object` | no | Редактированные детали. |
| `signature_state` | `string(enum)` | yes | unsigned/pending/signed/verified. |

## Инварианты

1. sequence_no должен возрастать монотонно в рамках одного журнала;
2. event_time_utc обязателен;
3. details_redacted не должны содержать секреты, plaintext essence и приватные ключи.

## Связи с другими объектами

- Связан почти со всеми security-critical операциями проекта.

## Каноническая сериализация (JSON)

```json
{
  "event_id": "evt-1001",
  "sequence_no": 1001,
  "event_time_utc": "2026-03-10T10:15:03Z",
  "event_type": "show_authorization",
  "severity": "info",
  "session_id": "sess-1",
  "result": "success",
  "signature_state": "signed"
}
```

## Причины отклонения / ошибки

- `missing_event_time`
- `non_monotonic_sequence`
- `secret_material_in_details`

## Замечания по эволюции

- Структура details_redacted может расширяться, если не ломает базовую семантику события.
