# PackingList

Статус: draft
Версия: 0.1

## Назначение

Каноническое представление PKL.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `packing_list_id` | `string` | yes | Идентификатор PKL. |
| `annotation_text` | `string` | no | Человекочитаемый заголовок. |
| `creator` | `string` | no | Создатель metadata. |
| `issuer` | `string` | no | Issuer metadata. |
| `issue_date_utc` | `string(datetime)` | no | Время выпуска PKL. |
| `is_signed` | `boolean` | yes | Есть ли подпись PKL. |
| `signer_thumbprint` | `string` | no | Отпечаток сертификата подписанта. |
| `assets` | `array<AssetRef>` | yes | Assets, объявленные в PKL. |

## Инварианты

1. packing_list_id обязателен;
2. если is_signed=true, signer_thumbprint должен быть либо известен, либо диагностика должна явно фиксировать unknown signer;
3. asset_id внутри assets уникальны.

## Связи с другими объектами

- Используется для проверки целостности и наполнения CompositionGraph.

## Каноническая сериализация (JSON)

```json
{
  "packing_list_id": "urn:uuid:...",
  "is_signed": true,
  "assets": [ { "asset_id": "urn:uuid:...", "asset_type": "picture", "path": "VIDEO.mxf" } ]
}
```

## Причины отклонения / ошибки

- `missing_pkl_id`
- `duplicate_asset_id`
- `signature_validation_failed`

## Замечания по эволюции

- Проверка XML signature может жить вне первичного parser stage, но объект должен фиксировать результат.
