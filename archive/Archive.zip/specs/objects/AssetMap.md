# AssetMap

Статус: draft
Версия: 0.1

## Назначение

Каноническое представление ASSETMAP.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `asset_map_id` | `string` | no | Идентификатор AssetMap, если присутствует в варианте формата. |
| `package_root` | `string` | yes | Абсолютный или нормализованный корень пакета. |
| `creator` | `string` | no | Идентификация создателя metadata. |
| `issuer` | `string` | no | Идентификация issuer. |
| `issue_date_utc` | `string(datetime)` | no | Время выпуска metadata. |
| `assets` | `array<AssetRef>` | yes | Все assets, объявленные в ASSETMAP. |

## Инварианты

1. комбинация package_root + path определяет единственное расположение asset;
2. в assets не допускаются дубликаты asset_id;
3. ASSETMAP не несёт playout semantics сам по себе.

## Связи с другими объектами

- Служит входом для PackingList и CompositionGraph resolver.

## Каноническая сериализация (JSON)

```json
{
  "package_root": "/data/dcp",
  "assets": [ { "asset_id": "urn:uuid:...", "asset_type": "cpl", "path": "CPL.xml" } ]
}
```

## Причины отклонения / ошибки

- `missing_assets`
- `duplicate_asset_id`
- `broken_path_reference`

## Замечания по эволюции

- Если upstream формат не содержит явный id, поле asset_map_id может отсутствовать.
