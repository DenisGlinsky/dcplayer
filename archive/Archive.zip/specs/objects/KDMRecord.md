# KDMRecord

Статус: draft
Версия: 0.1

## Назначение

Каноническое представление KDM и связанной policy.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `kdm_id` | `string` | yes | Идентификатор KDM. |
| `cpl_id` | `string` | yes | CPL, к которому относится KDM. |
| `key_ids` | `array<string>` | yes | Список ключевых идентификаторов. |
| `content_title_text` | `string` | no | Человекочитаемое название. |
| `valid_from_utc` | `string(datetime)` | yes | Начало окна показа. |
| `valid_until_utc` | `string(datetime)` | yes | Конец окна показа. |
| `recipient_thumbprint_sha256` | `string` | yes | Получатель KDM. |
| `signer_thumbprint_sha256` | `string` | no | Подписант KDM. |
| `forensic_marking_policy` | `string(enum)` | yes | picture/audio/both/none/unknown. |
| `status` | `string(enum)` | yes | valid/expired/future/malformed/rejected. |
| `source_path` | `string` | no | Откуда KDM был импортирован. |

## Инварианты

1. valid_from_utc < valid_until_utc;
2. cpl_id обязателен;
3. status=valid допускается только при непротиворечивых датах и recipient match.

## Связи с другими объектами

- Используется PlaybackSession authorization и security logging.

## Каноническая сериализация (JSON)

```json
{
  "kdm_id": "urn:uuid:...",
  "cpl_id": "urn:uuid:...",
  "key_ids": ["urn:uuid:key-1"],
  "valid_from_utc": "2026-03-10T10:00:00Z",
  "valid_until_utc": "2026-03-12T23:00:00Z",
  "forensic_marking_policy": "both",
  "status": "valid"
}
```

## Причины отклонения / ошибки

- `missing_cpl_id`
- `invalid_validity_window`
- `recipient_mismatch`
- `missing_key_ids`

## Замечания по эволюции

- Payload KDM может не храниться в этом объекте целиком; здесь фиксируется operational summary.
