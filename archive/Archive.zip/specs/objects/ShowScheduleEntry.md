# ShowScheduleEntry

Статус: draft
Версия: 0.1

## Назначение

Минимальная каноническая запись расписания показа для SMS/TMS.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `schedule_id` | `string` | yes | Идентификатор записи расписания. |
| `screen_id` | `string` | yes | Идентификатор зала/экрана. |
| `cpl_id` | `string` | yes | Композиция, запланированная к показу. |
| `playlist_label` | `string` | no | Операторская метка/название. |
| `planned_start_utc` | `string(datetime)` | yes | Плановый старт. |
| `planned_end_utc` | `string(datetime)` | yes | Плановое окончание. |
| `kdm_status` | `string(enum)` | yes | ok/missing/expired/future/error. |
| `asset_status` | `string(enum)` | yes | ok/missing/error. |
| `fm_policy` | `string(enum)` | yes | picture/audio/both/none/unknown. |
| `state` | `string(enum)` | yes | planned/ready/running/completed/failed/cancelled. |
| `automation_profile` | `string` | no | Связанный automation preset/profile. |

## Инварианты

1. planned_start_utc < planned_end_utc;
2. screen_id и cpl_id обязательны;
3. state=ready требует как минимум kdm_status=ok или mode=open.

## Связи с другими объектами

- Используется SMS/TMS, PlaybackSession и alerts.

## Каноническая сериализация (JSON)

```json
{
  "schedule_id": "sched-1",
  "screen_id": "screen-1",
  "cpl_id": "urn:uuid:...",
  "planned_start_utc": "2026-03-10T18:00:00Z",
  "planned_end_utc": "2026-03-10T20:15:00Z",
  "kdm_status": "ok",
  "asset_status": "ok",
  "fm_policy": "both",
  "state": "ready"
}
```

## Причины отклонения / ошибки

- `invalid_schedule_window`
- `missing_screen_id`
- `missing_cpl_id`

## Замечания по эволюции

- Это минимальная operational модель, а не полный TMS playlist object.
