# Reel

Статус: draft
Версия: 0.1

## Назначение

Отдельный reel внутри CPL.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `reel_id` | `string` | yes | Идентификатор reel. |
| `ordinal` | `integer` | yes | Позиция reel в составе CPL, начиная с 1. |
| `main_picture` | `TrackResource|null` | no | Главный picture resource. |
| `main_sound` | `TrackResource|null` | no | Главный sound resource. |
| `subtitle` | `TrackResource|null` | no | Subtitle/timed text resource. |
| `auxiliary_tracks` | `array<TrackResource>` | no | Прочие track resources. |
| `duration_frames` | `integer` | no | Итоговая длительность reel в кадрах. |

## Инварианты

1. ordinal > 0;
2. reel должен иметь хотя бы один ресурс;
3. main_picture/main_sound/subtitle не должны дублировать один и тот же resource id.

## Связи с другими объектами

- Принадлежит CompositionPlaylist; использует TrackResource.

## Каноническая сериализация (JSON)

```json
{
  "reel_id": "urn:uuid:...",
  "ordinal": 1,
  "main_picture": { "resource_id": "res-1" }
}
```

## Причины отклонения / ошибки

- `missing_reel_id`
- `empty_reel`
- `duplicate_resource_binding`

## Замечания по эволюции

- Допускается отсутствие отдельных типов ресурсов в диагностических или неполных графах.
