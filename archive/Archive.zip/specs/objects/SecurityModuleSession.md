# SecurityModuleSession

Статус: draft
Версия: 0.1

## Назначение

Состояние доверенной сессии между media server и secure module.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `session_id` | `string` | yes | Идентификатор сессии. |
| `device_id` | `string` | yes | Идентификатор secure module. |
| `client_cert_thumbprint_sha256` | `string` | yes | Отпечаток клиентского cert. |
| `server_cert_thumbprint_sha256` | `string` | yes | Отпечаток серверного cert. |
| `mtls_state` | `string(enum)` | yes | new/established/failed/closed. |
| `acl_subject` | `string` | no | Логический субъект ACL. |
| `clock_state` | `string(enum)` | yes | unknown/synced/out_of_policy. |
| `opened_at_utc` | `string(datetime)` | yes | Время открытия. |
| `last_activity_utc` | `string(datetime)` | yes | Время последней активности. |
| `session_state` | `string(enum)` | yes | idle/armed/authorized/in_playout/failed/closed. |

## Инварианты

1. session_id обязателен;
2. mtls_state=established требуется для состояний armed/authorized/in_playout;
3. clock_state не может быть unknown в authorized/in_playout.

## Связи с другими объектами

- Связан с PlaybackSession и SecurityLogEvent.

## Каноническая сериализация (JSON)

```json
{
  "session_id": "sess-1",
  "device_id": "pi-zymkey-01",
  "mtls_state": "established",
  "clock_state": "synced",
  "session_state": "authorized"
}
```

## Причины отклонения / ошибки

- `invalid_state_transition`
- `missing_cert_thumbprint`
- `clock_out_of_policy`

## Замечания по эволюции

- Объект описывает контрольную сессию, а не хранит секреты или plaintext essence.
