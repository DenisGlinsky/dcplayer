# TrackFile

Статус: draft
Версия: 0.1

## Назначение

Нормализованное представление essence-bearing файла.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `track_file_id` | `string` | yes | Идентификатор track file. |
| `asset_id` | `string` | yes | Ссылка на AssetRef. |
| `essence_kind` | `string(enum)` | yes | picture/sound/subtitle/timed_text/aux. |
| `path` | `string` | yes | Относительный путь к MXF/XML asset. |
| `is_encrypted` | `boolean` | yes | Признак encrypted essence. |
| `key_id` | `string` | no | Идентификатор ключа для encrypted essence. |
| `edit_rate` | `string` | no | Локальная edit rate, если применимо. |
| `intrinsic_duration` | `integer` | no | Intrinsic duration. |
| `language` | `string` | no | Язык сущности. |

## Инварианты

1. track_file_id обязателен;
2. если is_encrypted=true, key_id должен быть известен либо помечен диагностикой;
3. path должен быть относительным.

## Связи с другими объектами

- Используется TrackResource и CompositionGraph.

## Каноническая сериализация (JSON)

```json
{
  "track_file_id": "urn:uuid:...",
  "asset_id": "urn:uuid:...",
  "essence_kind": "sound",
  "path": "AUDIO.mxf",
  "is_encrypted": false
}
```

## Причины отклонения / ошибки

- `missing_track_file_id`
- `missing_asset_reference`
- `encrypted_without_key_id`

## Замечания по эволюции

- TrackFile и AssetRef разделены, чтобы изолировать metadata package-level и playout-level.
