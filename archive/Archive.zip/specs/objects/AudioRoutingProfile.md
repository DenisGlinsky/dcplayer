# AudioRoutingProfile

Статус: draft
Версия: 0.1

## Назначение

Каноническое описание routing профиля audio output.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `profile_id` | `string` | yes | Идентификатор профиля. |
| `sample_rate_hz` | `integer` | yes | Частота дискретизации. |
| `bit_depth` | `integer` | yes | Глубина, например 24. |
| `channel_count` | `integer` | yes | Количество каналов. |
| `delivery_mode` | `string(enum)` | yes | pcm/aes3. |
| `routes` | `array<object>` | yes | Массив маршрутов label-driven routing. |
| `immersive_mode` | `string` | no | Резерв для будущих режимов. |

## Инварианты

1. sample_rate_hz > 0;
2. bit_depth > 0;
3. channel_count == len(routes) или явно зафиксирована причина отклонения;
4. каждый route должен иметь уникальный destination.

## Связи с другими объектами

- Используется PCM engine, AES3 adapter, SMS/TMS diagnostics.

## Каноническая сериализация (JSON)

```json
{
  "profile_id": "audio-main-7.1",
  "sample_rate_hz": 48000,
  "bit_depth": 24,
  "channel_count": 8,
  "delivery_mode": "pcm",
  "routes": [
    { "label": "L", "source_index": 0, "destination": "out1", "enabled": true },
    { "label": "R", "source_index": 1, "destination": "out2", "enabled": true }
  ]
}
```

## Причины отклонения / ошибки

- `invalid_sample_rate`
- `invalid_bit_depth`
- `duplicate_destination`

## Замечания по эволюции

- Маршрутизация должна быть label-driven, а не строиться только на позиции канала.
