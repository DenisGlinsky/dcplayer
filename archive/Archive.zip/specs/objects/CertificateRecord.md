# CertificateRecord

Статус: draft
Версия: 0.1

## Назначение

Каноническое представление X.509 сертификата и его operational состояния.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `certificate_id` | `string` | yes | Внутренний идентификатор записи. |
| `thumbprint_sha256` | `string` | yes | Отпечаток сертификата. |
| `subject` | `string` | yes | Subject DN или нормализованное имя. |
| `issuer` | `string` | yes | Issuer DN или нормализованное имя. |
| `serial_number` | `string` | yes | Серийный номер. |
| `not_before_utc` | `string(datetime)` | yes | Начало действия. |
| `not_after_utc` | `string(datetime)` | yes | Окончание действия. |
| `storage_backend` | `string(enum)` | yes | tpm2/zymkey/file/unknown. |
| `is_ca` | `boolean` | yes | Флаг CA. |
| `revocation_status` | `string(enum)` | yes | good/revoked/unknown. |
| `device_binding` | `string` | no | Логическая привязка к устройству или роли. |

## Инварианты

1. not_before_utc < not_after_utc;
2. thumbprint_sha256 обязателен;
3. storage_backend должен соответствовать реальному trust boundary.

## Связи с другими объектами

- Используется SecurityModuleSession, KDMRecord и control plane ACL.

## Каноническая сериализация (JSON)

```json
{
  "certificate_id": "cert-1",
  "thumbprint_sha256": "...",
  "subject": "CN=media-server-01",
  "issuer": "CN=dcplayer-intermediate-ca",
  "storage_backend": "tpm2",
  "revocation_status": "good"
}
```

## Причины отклонения / ошибки

- `invalid_validity_window`
- `missing_thumbprint`
- `unsupported_storage_backend`

## Замечания по эволюции

- Запись не хранит приватный ключ и не даёт доступа к нему.
