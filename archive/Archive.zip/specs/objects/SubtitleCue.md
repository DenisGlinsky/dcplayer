# SubtitleCue

Статус: draft
Версия: 0.1

## Назначение

Унифицированное представление subtitle/timed text cue.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `cue_id` | `string` | yes | Идентификатор cue. |
| `track_file_id` | `string` | yes | Источник subtitle track. |
| `cue_kind` | `string(enum)` | yes | interop/smpte_tt/png/unknown. |
| `language` | `string` | no | Язык cue. |
| `start_pts_ticks` | `integer` | yes | Время начала. |
| `end_pts_ticks` | `integer` | yes | Время окончания. |
| `text` | `string` | no | Текстовая репрезентация, если применимо. |
| `font_refs` | `array<string>` | no | Связанные font assets. |
| `bitmap_asset_id` | `string` | no | Связанный bitmap asset. |
| `screen_rect` | `object` | no | Геометрия отображения. |
| `z_order` | `integer` | no | Порядок наложения. |

## Инварианты

1. end_pts_ticks > start_pts_ticks;
2. cue_kind обязателен;
3. для text-based cue текст или структура содержимого должны быть доступны parser-уровню.

## Связи с другими объектами

- Используется subtitle compositor и timeline diagnostics.

## Каноническая сериализация (JSON)

```json
{
  "cue_id": "cue-1",
  "track_file_id": "urn:uuid:sub-1",
  "cue_kind": "smpte_tt",
  "start_pts_ticks": 240,
  "end_pts_ticks": 312,
  "text": "Пример строки"
}
```

## Причины отклонения / ошибки

- `invalid_time_window`
- `missing_track_file_id`
- `missing_subtitle_payload`

## Замечания по эволюции

- Cue intentionally абстрагирует различия Interop и SMPTE timed text на уровне playout.
