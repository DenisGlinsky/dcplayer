# FrameDescriptor

Статус: draft
Версия: 0.1

## Назначение

Описание отдельного picture frame в decode/mark/playout path.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `frame_id` | `string` | yes | Идентификатор кадра. |
| `reel_id` | `string` | yes | Родительский reel. |
| `track_file_id` | `string` | yes | Источник кадра. |
| `frame_number` | `integer` | yes | Порядковый номер внутри track/session. |
| `pts_ticks` | `integer` | yes | Канонический presentation timestamp. |
| `duration_ticks` | `integer` | yes | Длительность кадра. |
| `resolution` | `string` | yes | Например 2k/4k/custom WxH. |
| `pixel_format` | `string` | yes | Например xyz12le. |
| `colorspace` | `string` | yes | Ожидаемый colorspace. |
| `decode_backend` | `string` | no | Фактически использованный backend. |
| `watermark_state` | `string(enum)` | yes | pending/applied/skipped/failed. |

## Инварианты

1. frame_number >= 0;
2. duration_ticks > 0;
3. watermark_state обязателен для secure picture path.

## Связи с другими объектами

- Используется video decode, watermark subsystem и telemetry.

## Каноническая сериализация (JSON)

```json
{
  "frame_id": "frame-000001",
  "reel_id": "urn:uuid:reel-1",
  "track_file_id": "urn:uuid:trk-1",
  "frame_number": 0,
  "pts_ticks": 0,
  "duration_ticks": 1,
  "resolution": "4k",
  "pixel_format": "xyz12le",
  "colorspace": "xyz",
  "watermark_state": "pending"
}
```

## Причины отклонения / ошибки

- `missing_track_file_id`
- `invalid_duration`
- `invalid_watermark_state`

## Замечания по эволюции

- Объект метаданных; сам кадр/буфер хранится отдельно.
