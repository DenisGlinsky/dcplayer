# AssetRef

Статус: draft
Версия: 0.1

## Назначение

Ссылка на отдельный asset внутри DCP package или derived graph.

## Канонические поля

| Поле | Тип | Обяз. | Описание |
|---|---|---|---|
| `asset_id` | `string(uuid-like)` | yes | Идентификатор asset. |
| `asset_type` | `string(enum)` | yes | Тип asset: picture/sound/subtitle/timed_text/font/cpl/pkl/assetmap/unknown. |
| `path` | `string` | yes | Относительный путь от package root. |
| `hash_algorithm` | `string` | no | Алгоритм хеша, например sha1 или sha256. |
| `hash_value` | `string` | no | Hex/base64 значение digest. |
| `size_bytes` | `integer` | no | Ожидаемый размер файла. |
| `packing_list_id` | `string` | no | Связь с PKL, если asset пришёл из PKL. |
| `annotation_text` | `string` | no | Человекочитаемая аннотация, если есть. |

## Инварианты

1. path всегда относительный и не должен содержать traversal за package root;
2. если задан hash_value, должен быть задан hash_algorithm;
3. asset_id уникален в пределах одного AssetMap/PKL представления.

## Связи с другими объектами

- Используется объектами AssetMap, PackingList, CompositionGraph.

## Каноническая сериализация (JSON)

```json
{
  "asset_id": "urn:uuid:...",
  "asset_type": "picture",
  "path": "VOLINDEX/ASSET-001.mxf",
  "hash_algorithm": "sha1",
  "hash_value": "...",
  "size_bytes": 123456789
}
```

## Причины отклонения / ошибки

- `missing_path`
- `non_relative_path`
- `hash_without_algorithm`
- `duplicate_asset_id`

## Замечания по эволюции

- Допускается расширение поля asset_type без ломки существующей сериализации.
