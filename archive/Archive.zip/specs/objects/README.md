# Companion object specifications

Эта директория хранит **формальные companion-спецификации** доменных, security и operational объектов проекта.
Спецификация — это не комментарий к коду, а канонический контракт, который Codex обязан держать синхронным с реализацией.

## Зачем это нужно

- фиксировать семантику объектов до появления большого объёма кода;
- отделять архитектурное решение от конкретной реализации;
- держать стабильной сериализацию для CLI, SMS/TMS и диагностики;
- не допускать тихого дрейфа полей и инвариантов.

## Общие правила

1. Для каждого объекта есть отдельный `*.md` файл.
2. Каноническая JSON-сериализация использует `snake_case`.
3. Время хранится в UTC ISO-8601 с суффиксом `Z`.
4. UUID/идентификаторы передаются строками.
5. Если объект меняется семантически, нужно:
   - обновить соответствующую спецификацию;
   - обновить task-specific `AGENTS.md`, если меняется scope задачи;
   - обновить `docs/STATUS.md`, если изменился статус проекта;
   - при изменении trust boundary — создать ADR.

## Стандартная структура спецификации

Каждый файл содержит:
- назначение;
- канонические поля;
- инварианты;
- связи с другими объектами;
- каноническую сериализацию;
- причины отклонения/ошибки;
- замечания по эволюции.

## Набор текущих объектов

- `AssetRef.md`
- `AssetMap.md`
- `PackingList.md`
- `CompositionPlaylist.md`
- `Reel.md`
- `TrackFile.md`
- `TrackResource.md`
- `CompositionGraph.md`
- `SupplementalBinding.md`
- `CertificateRecord.md`
- `KDMRecord.md`
- `SecurityModuleSession.md`
- `PlaybackSession.md`
- `FrameDescriptor.md`
- `AudioRoutingProfile.md`
- `SubtitleCue.md`
- `WatermarkPayload.md`
- `SecurityLogEvent.md`
- `ShowScheduleEntry.md`
