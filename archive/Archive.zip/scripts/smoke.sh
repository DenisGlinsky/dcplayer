#!/usr/bin/env bash
set -euo pipefail

./scripts/bootstrap.sh

if [ -d build ]; then
  ctest --test-dir build --output-on-failure || true
fi

echo "Smoke checks finished"
