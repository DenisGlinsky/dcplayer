#!/usr/bin/env bash
set -euo pipefail

if ! command -v cmake >/dev/null 2>&1; then
  echo "cmake not found" >&2
  exit 1
fi

generator="Ninja"
if ! command -v ninja >/dev/null 2>&1; then
  generator="Unix Makefiles"
fi

cmake -S . -B build -G "${generator}" -DCMAKE_BUILD_TYPE=RelWithDebInfo -DDCP_PLAYER_ENABLE_TESTS=ON
echo "Configured build/ using ${generator}"
