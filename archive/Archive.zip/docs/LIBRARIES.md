# LIBRARIES

Документ фиксирует рекомендуемые и допустимые библиотеки.
Любая новая зависимость должна сначала появиться здесь.

## 1. Политика отбора

Предпочтение получают зависимости:
- с понятной лицензией;
- с активным сопровождением;
- с понятной ролью в архитектуре;
- с возможностью детерминированного использования;
- без "магического" скрытого runtime.

## 2. Основные библиотеки

| Библиотека | Роль | Статус | Лицензия / режим | Комментарий |
|---|---|---|---|---|
| asdcplib | DCP/MXF low-level I/O | preferred | BSD-style permissive | Базовый кандидат для ASSETMAP/PKL/CPL/MXF layer. Точный upstream tag фиксировать перед vendoring. |
| OpenJPEG | CPU JPEG2000 fallback | approved | BSD-2-Clause | Обязательный reference/fallback backend. |
| nvJPEG2000 | NVIDIA GPU JPEG2000 | approved-candidate | vendor SDK terms | Не вендорить в репозиторий; использовать системную/SDK поставку. |
| OpenSSL 3 | TLS, X.509, crypto primitives | approved | Apache-2.0 | Базовый TLS/crypto стек. |
| tpm2-openssl | TPM integration for OpenSSL 3 | approved | BSD-3-Clause | Предпочтительный путь для Ubuntu/OpenSSL 3. |
| tpm2-pkcs11 | PKCS#11 bridge to TPM 2.0 | approved-fallback | BSD-2-Clause | Использовать как compatibility path, когда нужен PKCS#11. |
| Zymbit SDK / ZymKey APIs | ZymKey integration | required-on-pi | vendor terms | Источник для sign / lock-unlock / hardware integration. |
| zkpkcs11 | PKCS#11 integration for ZymKey | candidate | vendor terms | Использовать, если это упрощает CSR/TLS use-case на Pi. |
| pugixml | XML parsing | approved | MIT | Лёгкий DOM/XPath parser для внутреннего разбора XML. |
| xmlsec1 + libxml2 | XMLDSig / XML security / schema-sensitive tasks | approved-candidate | MIT-family | Нужны для проверок подписей и security-sensitive XML операций. |
| nlohmann/json | JSON serialization | approved | MIT | Для CLI-отчётов, diagnostics, status payloads. |
| spdlog | structured logging | approved | MIT | Операционные логи; security logs всё равно проходят отдельную защиту. |
| Catch2 | C++ unit/integration tests | approved | BSL-1.0 | Простой вход в тесты и bench-like checks. |

## 3. Reference-only и исключённые варианты

| Компонент | Статус | Причина |
|---|---|---|
| libdcp | reference only | Полезна как oracle и tooling, но не в product core. |
| DCP-o-matic | behavioral reference | Использовать как внешнюю точку сравнения, не как embedded dependency. |
| случайные watermark SDK без фиксированного контракта | excluded | Ломают стабильность object model и task isolation. |

## 4. Правила подключения зависимостей

1. Сначала оценить лицензию.
2. Сначала описать роль библиотеки в архитектуре.
3. Сначала определить fallback или exit strategy.
4. Не тянуть библиотеку "на всякий случай".
5. Любая vendor SDK должна быть изолирована adapter-слоем.

## 5. Специальные решения по security plane

### Ubuntu media server
Предпочтительно:
- OpenSSL 3 + `tpm2-openssl` provider;
- при необходимости PKCS#11 bridge через `tpm2-pkcs11`.

### Raspberry Pi + ZymKey
Допустимо:
- прямой вызов Zymbit SDK;
- ZymKey OpenSSL engine / helper tooling;
- `zkpkcs11`, если это упрощает CSR/TLS workflow.

## 6. Что нужно документировать при добавлении новой библиотеки

- exact version/tag;
- license;
- build/packaging mode;
- runtime assumptions;
- security impact;
- fallback path;
- кто является owner внутри проекта.
