# ARCHITECTURE

## 1. Назначение

`dcplayer` — это DCP playback appliance, проектируемый как программно-аппаратный комплекс для кинотеатральной демонстрации.
На этапе MVP целевая платформа — Linux Ubuntu, но структура репозитория сразу закладывается кросс-платформенно.

Документ фиксирует:
- общую архитектуру;
- trust boundaries;
- secure/open modes;
- цепочку playout;
- роль Raspberry Pi + ZymKey + RTC и Ubuntu + TPM 2.0;
- место forensic watermark;
- области, которые могут быть изменены только через ADR.

## 2. Ключевые проектные утверждения

1. Base flow остаётся: `ingest -> verify -> local storage -> playout`.
2. Secure show pipeline фиксирован так:
   `local storage -> HSM decrypt service (Raspberry Pi + ZymKey + RTC) -> GPU decode -> GPU picture FM -> playout`.
3. Для audio в secure show context действует зеркальная логика:
   `local storage -> secure authorization -> decrypt -> audio FM -> PCM/AES3 path`.
4. Pi + ZymKey — это root of trust для server-side secure control plane.
5. Ubuntu media server + TPM 2.0 — доверенный клиент secure control plane.
6. Mutual TLS, CRL/OCSP, signed/encrypted logging, RBAC и secure clock — обязательны.
7. Watermark — это не add-on после факта, а обязательная встроенная часть playout.
8. Любое ускорение обязано иметь deterministic fallback.

## 3. Контекст системы

```text
[Ingest Storage] -- verified assets --> [Local Storage]
                                    |
                                    v
                       [Media Server / Ubuntu / TPM 2.0]
                          | parser / resolver / scheduler
                          | playback orchestrator
                          | GPU decode + GPU FM
                          v
                [Secure control plane over mutual TLS]
                          ^
                          |
                [Raspberry Pi + ZymKey + RTC module]
                  - server cert/private key in ZymKey
                  - secure clock
                  - show authorization
                  - key release / unwrap / decrypt service
                  - signed security logs
```

## 4. Trusted appliance boundary

В проекте фиксируется **двухконтурная модель**.

### 4.1 Root-of-trust boundary

Это наиболее жёсткая граница доверия:

- Raspberry Pi + ZymKey + RTC;
- TPM 2.0 на media server;
- сертификаты устройств;
- mutual-TLS аутентификация;
- secure clock;
- security logs;
- escrow / recovery policy;
- tamper reaction.

### 4.2 Ephemeral clear-data boundary

В active show session допустим временный доступ к clear codestream / frame / PCM только внутри доверенного playback appliance и только в volatile memory.
Для этого вводятся правила:

- plaintext essence не записывается на диск;
- plaintext buffers имеют явный lifetime и zeroization;
- GPU surfaces не считаются хранилищем и не снапшотятся;
- debug dump отключён в secure mode;
- любое внешнее соединение после GPU FM должно быть защищённым;
- secure logs отражают запуск, остановку, аварийное завершение и purge.

## 5. Два режима работы

### 5.1 Open / lab mode

Предназначен для:
- open DCP;
- разработки и диагностики;
- исследования GPU backend;
- lab watermark experiments.

Разрешается:
- CPU and GPU decoding;
- расширенное логирование;
- reference backends.

Не разрешается:
- путать его с production secure show mode;
- выдавать его за финальную security model.

### 5.2 Secure show mode

Предназначен для:
- encrypted DCP;
- реального показа;
- строгого учёта KDM/show window;
- активного forensic marking;
- защищённого output chain.

Отличия:
- show clock и policy приходят из secure module;
- decrypt stage запускается только после успешной mutual-TLS сессии и проверки окна показа;
- plaintext не сохраняется на persistent storage;
- логи событий подписываются и цепляются хешами;
- FM policy включается как часть show authorization.

## 6. Контрольная плоскость: Raspberry Pi + ZymKey + TPM

В качестве исходного развертывательного паттерна принимается схема из прикладного документа по ZymKey/TPM:

- Raspberry Pi + ZymKey выступает TLS-сервером;
- media server (Ubuntu + TPM 2.0) выступает TLS-клиентом;
- приватный серверный ключ остаётся внутри ZymKey;
- приватный клиентский ключ остаётся внутри TPM;
- mutual-TLS должен проверять цепочку сертификатов;
- CRL/OCSP и ACL обязательны;
- операции логируются локально и в зашифрованный журнал;
- SSH — только через jump-host, доступ — через MFA/RBAC;
- recovery/escrow, tamper policy и физическая защита обязательны.

Для нашего проекта этот паттерн расширяется с `/sign` до набора secure playback API:

- `POST /session/open`
- `POST /session/authorize-show`
- `POST /kdm/import`
- `POST /keys/unwrap`
- `POST /decrypt/start`
- `POST /decrypt/stop`
- `POST /logs/upload`
- `POST /tamper/report`
- `GET /time/utc`
- `GET /health`

Важно: это **архитектурный контракт**, а не обещание конкретной URI-схемы.
URI и wire-format могут уточняться, но trust model меняться не должна.

## 7. Что именно означает "decrypt in HSM"

В проекте это выражение трактуется инженерно, а не маркетингово.

- ZymKey — аппаратный якорь доверия, хранение server key, подпись, lock/unlock, secure policy и tamper.
- Raspberry Pi sidecar — вычислительная часть secure module.
- Bulk decrypt может выполняться в процессе secure daemon, если ключевой материал выпускается только в защищённой сессии и не покидает trusted module semantics.

То есть "расшифровка в HSM" для проекта означает:
1. release/unwrap content keys разрешает только secure module;
2. decrypt stage находится в trust boundary secure module;
3. media server не получает долговременный доступ к ключам;
4. plaintext не попадает в local storage и не экспортируется;
5. по окончании показа выполняется zeroization и логируется purge.

### Риск-гейт

Raspberry Pi + ZymKey как decrypt sidecar обязаны пройти throughput-бенчмарки на целевых пакетах.
Если голая конфигурация не держит требуемый поток, допускается перенос bulk AES stage в adjacent trusted compute внутри того же secure module envelope, но:
- API к host не меняется;
- security semantics не меняются;
- release policy остаётся под ZymKey/RTC;
- companion-спецификации не ломаются.

## 8. Playback graph

### 8.1 Ingest graph

```text
DCP source
  -> ASSETMAP/PKL/CPL parse
  -> hash/signature verification
  -> asset inventory
  -> local storage
  -> composition graph
  -> schedule readiness
```

### 8.2 Secure playback graph

```text
Local Storage
  -> composition resolve
  -> show authorization
  -> HSM decrypt service
  -> JPEG2000 codestream ready
  -> GPU decode
  -> GPU picture forensic watermark
  -> subtitle composite
  -> output adapter
  -> projector / protected path
```

### 8.3 Audio graph

```text
Local Storage
  -> composition resolve
  -> secure authorization
  -> PCM essence fetch/decrypt
  -> audio forensic watermark
  -> channel routing by labels
  -> output adapter
  -> PCM now / AES3 later
```

## 9. Picture pipeline

Целевой picture path:

1. MXF picture essence read.
2. Optional secure decrypt depending on composition.
3. JPEG2000 codestream handoff.
4. J2K decode backend selection:
   - CPU fallback: OpenJPEG;
   - NVIDIA path: nvJPEG2000;
   - other GPU paths — R&D / later;
   - secure adapter remains stable regardless of backend.
5. Frame queue in XYZ-oriented internal representation.
6. Inline picture watermark.
7. Subtitle/subpicture composite.
8. Protected output stage.

Требования:
- zero-copy между decode и FM там, где возможно;
- no host disk dumps in secure mode;
- frame ordering strictly monotonic;
- deterministic fallback to CPU path.

## 10. Audio pipeline

На текущем этапе аудио делится на две фазы.

### Phase A
- internal PCM engine;
- label-driven routing;
- sync to show clock;
- software audio forensic marking;
- Linux-first output.

### Phase B
- 24-bit AES3 output adapter;
- cinema processor / automation integration;
- production calibration and compliance tests.

Правило: никакого жёсткого mapping по номеру канала без metadata-driven routing.

## 11. Subtitles и supplemental

Обязательные подсистемы:
- Interop subtitles / subpictures;
- SMPTE timed text;
- font asset handling;
- OV/VF resolver;
- supplemental composition binding;
- diagnostics на missing assets, edit-rate mismatch, broken references.

`CompositionGraph` считается единственной правдой для playout.
Нельзя играть CPL напрямую, минуя этап разрешения OV/VF/supplemental.

## 12. Watermark architecture

Watermark — обязательная inline-подсистема.

### 12.1 Слои

1. `payload planner` — формирует идентификационные данные.
2. `embed backend` — внедряет метку в picture/audio.
3. `control plane` — получает policy из secure session.
4. `detector harness` — извлекает и верифицирует метку офлайн.
5. `self-test` — прогоняет attack matrix на каждой backend-реализации.

### 12.2 Почему watermark "pluggable"

Потому что у системы должен быть неизменный внешний контракт, но заменяемый внутренний алгоритм или ускоритель.
Это нужно для:
- замены CPU backend на GPU backend;
- сравнения research and production implementations;
- сертификационных / юридических сценариев;
- возможности сменить алгоритм без переписывания playout и TMS.

### 12.3 Attack matrix фиксируется отдельно

Минимальный набор сценариев для picture:
- re-encode;
- resize;
- crop;
- blur;
- gamma/brightness shift;
- frame blend;
- screen-cam.

Для audio:
- AAC/MP3 transcode;
- room capture;
- resample;
- EQ;
- dynamics;
- gain changes;
- noise injection.

## 13. TMS / SMS

### SMS
Локальный контур одного зала:
- show control;
- playout status;
- health;
- local alerts;
- manual operations.

### TMS
Центральный контур:
- inventory;
- CPL/KDM status;
- schedule;
- alerts;
- remote launch/stop;
- log collection summary.

MVP TMS deliberately минимален и не вторгается в real-time media loop.

## 14. Security logs и observability

В проекте логирование делится на три уровня:

1. **Security logs**
   - show authorization;
   - KDM import/validation;
   - secure session open/close;
   - tamper events;
   - FM state;
   - purge events.
   Эти события подписываются и связываются hash chain.

2. **Operational logs**
   - ingest;
   - resolver diagnostics;
   - health metrics;
   - device discovery;
   - non-sensitive service diagnostics.

3. **Performance telemetry**
   - decode latency;
   - queue depth;
   - jitter;
   - watermark insertion cost;
   - audio/video sync deltas.

Secure mode никогда не логирует plaintext essence.

## 15. Основные открытые решения

1. Подтвердить throughput decrypt sidecar на Raspberry Pi + ZymKey.
2. Зафиксировать production watermark algorithm/payload size.
3. Выбрать финальный TMS web stack для MVP.
4. Решить финальный secure output adapter и схему link protection.
5. Уточнить hardware matrix для non-NVIDIA GPU backend.

## 16. Что может меняться только через ADR

- trust boundaries;
- secure/open mode semantics;
- object invariants;
- watermark contract;
- audio output contract;
- host <-> secure module API class;
- key/certificate lifecycle;
- logging chain semantics.

## 17. Reference notes

При проектировании этого документа учитывались:
- приложенный deployment note про Raspberry Pi + ZymKey + TPM (mutual-TLS, ACL, encrypted journaling, tamper, recovery);
- документация Zymbit по `sign`, `lock/unlock`, CSR и TLS-клиентской аутентификации;
- документация TPM2 OpenSSL provider / TPM2 PKCS#11;
- документация NVIDIA nvJPEG2000.
