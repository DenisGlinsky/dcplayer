# IMPLEMENT

## 1. Цель документа

Зафиксировать практический способ работы Codex и разработчиков внутри `dcplayer`, чтобы код появлялся маленькими принимаемыми срезами и не ломал security model.

## 2. Порядок чтения перед реализацией

1. `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/CODE_STYLE.md`
4. task-specific `tasks/<TASK-ID>/AGENTS.md`
5. связанные companion-спецификации в `specs/objects/`

## 3. Глобальный workflow

### Шаг 1. Принять task scope
У каждой задачи должны быть:
- цель;
- non-goals;
- входы;
- выходы;
- список модулей;
- DoD;
- тесты.

### Шаг 2. Проверить impact
Перед кодом нужно ответить:
- меняется ли trust boundary;
- меняется ли object shape;
- нужна ли новая зависимость;
- нужен ли ADR.

### Шаг 3. Реализовать минимальный вертикальный срез
Не делай "на будущее" соседние подсистемы.

### Шаг 4. Проверить
Минимум:
- сборка;
- unit/integration tests;
- smoke run;
- обновление companion-спек, если менялся контракт.

### Шаг 5. Отчитаться
Строго по `docs/templates/CODEX_REPORT.md`.

## 4. Обязательные инженерные правила

1. Сначала simulator, потом hardware.
2. Сначала reference path, потом optimized path.
3. Сначала validator/parser, потом playout.
4. Сначала object contracts, потом transport.
5. Сначала failure semantics, потом happy path polishing.

## 5. Реализация secure control plane

Приоритетный паттерн для Ubuntu 22.04+:
- OpenSSL 3;
- `tpm2-openssl` provider как основной путь интеграции TPM;
- `tpm2-pkcs11` как fallback/compatibility path;
- Zymbit SDK / `zkpkcs11` / ZymKey engine на стороне Pi.

### 5.1 Обязательные свойства control plane
- mutual TLS;
- client cert в TPM;
- server cert в ZymKey;
- CA chain + revocation checking;
- ACL на уровне device identity;
- signed local logs;
- encrypted archival logs;
- secure clock timestamps.

### 5.2 Что не делать
- не хранить приватные ключи на файловой системе;
- не использовать plaintext shared secret вместо client cert;
- не пускать show authorization мимо secure module;
- не смешивать operational API и secure API в один бесконтрольный endpoint set.

## 6. Реализация decrypt stage

Архитектурная формулировка:
- key release/unwrap и policy check живут в secure module;
- bulk decrypt выполняется внутри trusted module semantics;
- host orchestration не получает "свободные" content keys.

Практический совет:
- сначала написать `ISecurityModule` и simulator;
- потом wire contract;
- потом добавить zeroization, state machine и signed logs;
- только потом подключать реальное железо.

## 7. Реализация GPU decode

Интерфейс backend должен быть единым.

Пример абстракции:

```cpp
struct DecodeRequest;
struct DecodeResult;

class IJ2KBackend {
public:
    virtual ~IJ2KBackend() = default;
    virtual BackendInfo backend_info() const = 0;
    virtual Result<DecodeResult> decode(const DecodeRequest& request) = 0;
    virtual Result<void> self_test() = 0;
};
```

Минимальные backend-ветки:
- `j2k_cpu` — reference/fallback;
- `j2k_gpu_open` — optimized path;
- `secure_decode_adapter` — мост между secure show orchestration и конкретным decode backend.

## 8. Реализация forensic watermark

### 8.1 Что значит pluggable на уровне кода

В репозитории должен существовать единый контракт:

```cpp
class IForensicMarkingBackend {
public:
    virtual ~IForensicMarkingBackend() = default;
    virtual BackendInfo backend_info() const = 0;
    virtual CapabilitySet capabilities() const = 0;
    virtual Result<void> configure(const WatermarkPolicy&) = 0;
    virtual Result<void> mark_video(FrameDescriptor&, const WatermarkPayload&) = 0;
    virtual Result<void> mark_audio(AudioBuffer&, const WatermarkPayload&) = 0;
    virtual Result<DetectorReport> self_test(const AttackMatrix&) = 0;
};
```

Это нужно, чтобы:
- не переписывать playout при смене алгоритма;
- иметь reference backend;
- валидировать детектор отдельно;
- формально сравнивать candidate backends.

### 8.2 Что не считается pluggable
- произвольная загрузка неизвестных binary plugins во время показа;
- зависимость остальных модулей от конкретной реализации watermark;
- разный формат payload в разных backend-реализациях без versioned contract.

## 9. Обновление companion-спецификаций

Обязательно обновлять `specs/objects/*`, если меняется:
- имя поля;
- тип поля;
- состояние объекта;
- правила сериализации;
- инварианты;
- security semantics;
- relationships между объектами.

## 10. Что должно быть в каждой реализации

- deterministic behavior;
- explicit configuration;
- machine-readable errors;
- observability hooks;
- tests;
- documentation touchpoint.

## 11. Минимальный acceptance checklist для каждой задачи

- scope задачи соблюдён;
- новые зависимости отражены;
- спецификации синхронизированы;
- build и tests выполнены;
- security model не нарушена;
- отчёт подготовлен.

## 12. Когда нужно остановиться и поднять вопрос архитекторам

- если задача упирается в изменение trust boundary;
- если требуется новая криптографическая зависимость;
- если деградация производительности требует менять pipeline;
- если для исправления нужно расширить task scope больше чем на один соседний модуль;
- если implementation choice меняет объектные инварианты.
