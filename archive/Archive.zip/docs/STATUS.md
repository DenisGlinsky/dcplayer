# dcplayer — `docs/STATUS.md`

## 1. Назначение документа

Этот документ — единственный оперативный источник правды о **фактическом** состоянии проекта `dcplayer`.

- `docs/PLAN.md` отвечает на вопрос: **что и в каком порядке делать**;
- `docs/STATUS.md` отвечает на вопрос: **что реально сделано, что готово к запуску следующей веткой, что заблокировано и где находятся доказательства статуса**.

Рабочий корень проекта: `/Users/admin/Documents/dcplayer`.

Документ обязан обновляться **в конце каждой ветки Codex**. Если ветка не обновила `docs/STATUS.md`, она считается завершённой не полностью.

## 2. Правила честного статуса

### 2.1. Статус отражает только проверенное состояние

В этот документ нельзя писать желаемое состояние, обещания или предположения. Здесь фиксируется только то, что подтверждено артефактами, тестами, логами, диффами, handoff-отчётом и приёмкой.

### 2.2. Без evidence нет продвижения статуса

Правило строгое:

- без артефакта, лога, теста, файла или handoff-отчёта задача не может получить статус `DONE`;
- без читаемого результата ветка не может считаться `REVIEW`;
- без закрытых зависимостей задача не получает статус `READY`, даже если для неё уже написан task-specific `AGENTS.md`.

### 2.3. Спецификация важнее неявного кода

Если в ветке менялся объектный контракт, state machine, validation invariant, сериализация, формат лога или внешний API, соответствующий companion-spec должен быть обновлён **до** того, как задача получит статус `REVIEW` или `DONE`.

### 2.4. Нет тихого расширения scope

Если в ветке сделано больше, чем разрешено task-specific `AGENTS.md`, это нужно явно отразить в handoff и в этом документе. Нельзя поднимать статус нескольких задач одной веткой без отдельных доказательств по каждой.

### 2.5. Длинные доказательства хранятся в файлах

Полные логи, дампы, perf-отчёты, evidence-pack и acceptance traces должны лежать в файлах и артефактах. В `docs/STATUS.md` попадает только краткая ссылка на их наличие и итог.

## 3. Легенда статусов

Используются только следующие статусы:

- **PLANNED** — задача существует в плане, но не готова к старту из-за незакрытых зависимостей или отсутствия входных артефактов;
- **READY** — задача может быть взята в следующую ветку без дополнительной подготовки;
- **IN_PROGRESS** — по задаче открыта активная ветка и идёт работа;
- **REVIEW** — ветка завершена, есть артефакты и evidence, но приёмка ещё не зафиксирована;
- **BLOCKED** — задача начата или подготовлена, но не может двигаться из-за внешнего блокера;
- **DONE** — задача принята, evidence зафиксированы, handoff завершён;
- **CANCELLED** — задача сознательно снята или заменена другой.

Дополнительные рабочие маркеры:

- **FROZEN** — архитектурное решение или policy принято и не меняется без отдельного ADR/изменения плана;
- **UNVERIFIED** — информация существует, но не имеет достаточного доказательства для повышения статуса задачи.

## 4. Текущий снимок проекта

### 4.1. Снимок на 2026-03-09

Проект находится в состоянии **documentation freeze / pre-implementation baseline**.

Это означает:

- branch-sized план зафиксирован;
- порядок задач и границы веток определены;
- secure playback chain зафиксирована на уровне архитектуры;
- baseline для secure control-plane включён в проектные ограничения;
- companion-spec подход зафиксирован как обязательный;
- accepted implementation baseline пока не зафиксирован.

### 4.2. Что уже считается принятым на уровне архитектуры

Статус: **FROZEN**

Приняты следующие решения:

- двухконтурная архитектура `host-plane + secure-plane`;
- production chain для encrypted show:
  `local storage -> HSM decrypt service -> GPU decode -> GPU picture FM -> playout`;
- separate open/debug path не может тихо подменять secure path;
- audio roadmap: `Stage A = internal PCM engine`, `Stage B = 24-bit AES3 adapter`;
- picture FM входит в secure show path;
- sound FM ведётся отдельной веткой;
- критерий “100% идентификация” допускается только относительно утверждённой attack matrix;
- branch-sized discipline и операционный стоп задолго до предельного размера ветки.

### 4.3. Что встроено в security baseline

Статус: **FROZEN**

В security baseline встроены требования secure control-plane:

- Pi + ZymKey как TLS-сервер с приватным ключом внутри ZymKey;
- Ubuntu media server + TPM2 как TLS-клиент с клиентским ключом в TPM;
- mutual-TLS, client-certificate authentication, проверка цепочки и revocation;
- ACL, identity checks, локальный и защищённый аудит;
- tamper, recovery, escrow, time discipline;
- обязательные acceptance tests для handshake, sign/verify, ACL deny, tamper и recovery.

### 4.4. Что пока не считается сделанным

Статус: **UNVERIFIED**

На момент этого снимка отсутствует подтверждённая приёмкой реализация следующих подсистем:

- repository bootstrap в рабочем дереве проекта;
- baseline companion-specs, принятые в actual repo;
- DCP parsers;
- OV/VF/supplemental resolver;
- secure channel simulator;
- `ISecurityModule` + SPB1 simulator;
- KDM ingest and binding;
- fail-closed playback state machine;
- J2K decode stack;
- picture FM implementation;
- sound FM implementation;
- subtitles/audio playback;
- AES3 adapter;
- secure encrypted playout orchestrator;
- SMS/TMS.

Иными словами: **архитектурный baseline есть, принятой реализационной базы пока нет**.

## 5. Сводный статус по фазам

### Phase A — Основание проекта

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 1
- `PLANNED`: 2
- `BLOCKED`: 0

Фаза готова к запуску с `T00a`.

### Phase B — DCP domain model

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 3
- `BLOCKED`: 0

Фаза не может стартовать до принятия результатов Phase A.

### Phase C — Resolver и timeline

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 3
- `BLOCKED`: 0

### Phase D — Security control plane

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 5
- `BLOCKED`: 0

### Phase E — KDM и security module

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 4
- `BLOCKED`: 0

### Phase F — Decode backend stack

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 4
- `BLOCKED`: 0

### Phase G — Forensic watermark

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 5
- `BLOCKED`: 0

### Phase H — Audio and subtitles

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 5
- `BLOCKED`: 0

### Phase I — Playback orchestration

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 4
- `BLOCKED`: 0

### Phase J — SMS / TMS

- `DONE`: 0
- `REVIEW`: 0
- `IN_PROGRESS`: 0
- `READY`: 0
- `PLANNED`: 3
- `BLOCKED`: 0

## 6. Реестр задач

Ниже зафиксировано текущее состояние всех branch-sized задач из `docs/PLAN.md`.

---

## Phase A — Основание проекта

### T00a — Repository bootstrap

- **Статус:** `READY`
- **Класс ветки:** `XS`
- **Зависимости:** нет
- **Evidence:** план, структура фаз и task slicing зафиксированы; accepted implementation evidence для actual repo ещё нет
- **Следующий шаг:** открыть первую реализационную ветку и собрать минимальный репозиторный scaffold
- **Блокеры:** нет

### T00b — Formal companion specs freeze

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T00a`
- **Evidence:** baseline перечень companion-specs определён в `docs/PLAN.md`
- **Следующий шаг:** после приёмки `T00a` создать и заморозить baseline specs/objects
- **Блокеры:** `T00a` не принят

### T00c — Project memory discipline

- **Статус:** `PLANNED`
- **Класс ветки:** `XS`
- **Зависимости:** `T00a`
- **Evidence:** правила durable memory описаны документно, но не закреплены в actual repo и процессах handoff
- **Следующий шаг:** после `T00a` зафиксировать шаблоны handoff, naming и artifact layout
- **Блокеры:** `T00a` не принят

---

## Phase B — DCP domain model

### T01a — ASSETMAP + PKL parser

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T00a`, `T00b`
- **Evidence:** задача определена и ограничена
- **Следующий шаг:** старт после приёмки foundation-phase
- **Блокеры:** `T00a`, `T00b`

### T01b — CPL parser

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T01a`
- **Evidence:** зависимость и DoD зафиксированы
- **Следующий шаг:** старт после `T01a`
- **Блокеры:** `T01a`

### T01c — `dcp_probe` + composition graph

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T01a`, `T01b`
- **Evidence:** CLI scope определён
- **Следующий шаг:** старт после парсеров
- **Блокеры:** `T01a`, `T01b`

---

## Phase C — Resolver и timeline

### T02a — OV/VF resolver

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T01c`
- **Evidence:** resolver scope определён
- **Следующий шаг:** старт после composition graph
- **Блокеры:** `T01c`

### T02b — Supplemental semantics

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T02a`
- **Evidence:** merge/override semantics зафиксированы только на уровне плана
- **Следующий шаг:** старт после OV/VF resolver
- **Блокеры:** `T02a`

### T02c — Dry-run playback timeline

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T02a`, `T02b`
- **Evidence:** timeline scope определён
- **Следующий шаг:** старт после dry-run-ready composition graph
- **Блокеры:** `T02a`, `T02b`

---

## Phase D — Security control plane

### T03a — PKI and trust store baseline

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T00b`
- **Evidence:** security baseline зафиксирован архитектурно
- **Следующий шаг:** перевести baseline в object model и validation rules
- **Блокеры:** `T00b`

### T03b — Pi/ZymKey ↔ Ubuntu/TPM mutual-TLS contract

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T03a`
- **Evidence:** secure control-plane profile принят архитектурно, но не переведён в принятый контракт
- **Следующий шаг:** formal SecureChannelContract + sequence diagrams + acceptance criteria
- **Блокеры:** `T03a`

### T03c — ACL + protected API envelope

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T03b`
- **Evidence:** общая роль envelope описана в плане
- **Следующий шаг:** формализовать `/sign`, будущие `/unwrap` и `/decrypt`, audit fields и deny semantics
- **Блокеры:** `T03b`

### T03d — Audit, tamper, escrow, recovery

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T03b`, `T03c`
- **Evidence:** обязательность подсистемы закреплена архитектурно
- **Следующий шаг:** описать state transitions, export format и acceptance tests
- **Блокеры:** `T03b`, `T03c`

### T03e — Secure time semantics

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T03b`
- **Evidence:** time discipline признана обязательной
- **Следующий шаг:** formal SecureClockPolicy + negative tests на skew/window
- **Блокеры:** `T03b`

---

## Phase E — KDM и security module

### T04a — `ISecurityModule` + simulator

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T03c`, `T03e`
- **Evidence:** API surface перечислена, но не реализована и не принята
- **Следующий шаг:** поднять host-side контракт и simulator
- **Блокеры:** `T03c`, `T03e`

### T04b — KDM ingest and binding

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T04a`
- **Evidence:** поведение описано только на уровне плана
- **Следующий шаг:** реализовать ingest, binding и validation windows
- **Блокеры:** `T04a`

### T04c — Fail-closed playback state machine

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T04a`, `T04b`
- **Evidence:** правило fail-closed зафиксировано как архитектурный запрет silent fallback
- **Следующий шаг:** formal state machine + negative tests
- **Блокеры:** `T04a`, `T04b`

### T04d — Security event export

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T03d`, `T04a`
- **Evidence:** необходимость redacted export определена
- **Следующий шаг:** сформировать export policy и operator summaries
- **Блокеры:** `T03d`, `T04a`

---

## Phase F — Decode backend stack

### T05a — J2K backend abstraction

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T00b`
- **Evidence:** backend abstraction описана в плане
- **Следующий шаг:** formal backend contract + surfaces + error model
- **Блокеры:** `T00b`

### T05b — CPU reference decoder

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T05a`
- **Evidence:** baseline нужен как oracle/fallback, но реализации нет
- **Следующий шаг:** поднять reference path
- **Блокеры:** `T05a`

### T05c — GPU decode contract

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T05a`, `T03c`
- **Evidence:** secure chain требует явного handoff `decrypt -> decode`
- **Следующий шаг:** formal GPU memory / queue / sync contract
- **Блокеры:** `T05a`, `T03c`

### T05d — NVIDIA backend

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T05c`
- **Evidence:** production backend объявлен как целевой, но не начат
- **Следующий шаг:** после утверждения GPU contract собрать production backend
- **Блокеры:** `T05c`

---

## Phase G — Forensic watermark

### T06a — Watermark object model

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T00b`
- **Evidence:** FM как подсистема включён в архитектуру, но объектная модель не принята
- **Следующий шаг:** formal payload/state/evidence/attack matrix contracts
- **Блокеры:** `T00b`

### T06b — Detector harness

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T06a`
- **Evidence:** критерий идентификации без harness пока недействителен
- **Следующий шаг:** собрать offline harness и scoring rules
- **Блокеры:** `T06a`

### T06c — GPU picture FM prototype

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T06a`, `T05c`
- **Evidence:** picture FM обязателен для secure chain, но insertion path отсутствует
- **Следующий шаг:** реализовать insertion на GPU-path
- **Блокеры:** `T06a`, `T05c`

### T06d — Secure playback integration

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T06c`, `T04c`, `T05d`
- **Evidence:** secure show chain frozen, integration evidence нет
- **Следующий шаг:** связать `decrypt -> decode -> picture FM -> playout`
- **Блокеры:** `T06c`, `T04c`, `T05d`

### T06e — Sound FM reference path

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T06a`, `T07a`
- **Evidence:** sound FM выделен в отдельную ветку и ещё не начинался
- **Следующий шаг:** reference insertion + detector integration
- **Блокеры:** `T06a`, `T07a`

---

## Phase H — Audio and subtitles

### T07a — PCM engine + channel routing

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T00b`
- **Evidence:** audio roadmap frozen, реализация не начата
- **Следующий шаг:** internal PCM engine + label-driven routing
- **Блокеры:** `T00b`

### T07b — Audio clock and sync stabilization

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T07a`, `T02c`
- **Evidence:** задача определена
- **Следующий шаг:** ввести audio sync against playback timeline
- **Блокеры:** `T07a`, `T02c`

### T07c — AES3 adapter

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T07a`
- **Evidence:** adapter вынесен в отдельный subsystem, но реализационной базы нет
- **Следующий шаг:** formal device abstraction + tests
- **Блокеры:** `T07a`

### T07d — Interop subtitles

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T01c`, `T08a`
- **Evidence:** путь определён только в плане
- **Следующий шаг:** parser/timing/render integration
- **Блокеры:** `T01c`, `T08a`

### T07e — SMPTE timed text

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T01c`, `T08a`
- **Evidence:** путь определён только в плане
- **Следующий шаг:** parser/fonts/timing/render integration
- **Блокеры:** `T01c`, `T08a`

---

## Phase I — Playback orchestration

### T08a — Open playout orchestrator

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T02c`, `T05b`, `T07a`
- **Evidence:** open/debug path разрешён как отдельный режим, но реализация отсутствует
- **Следующий шаг:** собрать baseline local playback path
- **Блокеры:** `T02c`, `T05b`, `T07a`

### T08b — Secure playout orchestrator

- **Статус:** `PLANNED`
- **Класс ветки:** `L`
- **Зависимости:** `T04c`, `T05d`, `T06d`, `T07a`
- **Evidence:** full secure chain frozen только архитектурно
- **Следующий шаг:** orchestration full encrypted path
- **Блокеры:** `T04c`, `T05d`, `T06d`, `T07a`

### T08c — Fault matrix

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T04c`, `T08a`
- **Evidence:** explicit fault handling обязателен, но не описан в accepted artifacts
- **Следующий шаг:** собрать таблицу отказов и expected reactions
- **Блокеры:** `T04c`, `T08a`

### T08d — Encrypted show rehearsal

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T08b`, `T08c`
- **Evidence:** rehearsal runbook отсутствует
- **Следующий шаг:** провести scripted end-to-end rehearsal
- **Блокеры:** `T08b`, `T08c`

---

## Phase J — SMS / TMS

### T09a — Local SMS API

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T08a`
- **Evidence:** subsystem определён, но реализация не начата
- **Следующий шаг:** локальный control API для одного auditorium
- **Блокеры:** `T08a`

### T09b — Minimal TMS web

- **Статус:** `PLANNED`
- **Класс ветки:** `M`
- **Зависимости:** `T09a`, `T04d`
- **Evidence:** product scope зафиксирован в плане
- **Следующий шаг:** inventory + CPL/KDM status + alerts + remote launch
- **Блокеры:** `T09a`, `T04d`

### T09c — Monitoring and operator audit

- **Статус:** `PLANNED`
- **Класс ветки:** `S`
- **Зависимости:** `T09a`, `T04d`
- **Evidence:** observability scope не реализован
- **Следующий шаг:** unified operator-facing monitoring and audit view
- **Блокеры:** `T09a`, `T04d`

## 7. Следующие рекомендуемые ветки

Текущая очередь старта:

1. **`T00a — Repository bootstrap`**
2. **`T00b — Formal companion specs freeze`**
3. **`T00c — Project memory discipline`**
4. **`T01a — ASSETMAP + PKL parser`**
5. **`T01b — CPL parser`**

Правило очереди:

- не открывать новую тяжёлую реализационную ветку, пока предыдущая не оставила handoff;
- не брать security-heavy задачи раньше foundation/spec tasks;
- не начинать `T08b` до готовности `T04c`, `T05d`, `T06d`, `T07a`.

## 8. Текущие блокеры и управленческие запреты

### 8.1. Блокеров на старт первой ветки нет

`T00a` можно начинать немедленно.

### 8.2. Запрет на преждевременный secure-playout код

До принятия `T03a`–`T04c` запрещено писать production-like encrypted playback logic, которую потом придётся перепридумывать под fail-closed и secure-audit semantics.

### 8.3. Запрет на смешивание picture FM и sound FM

Picture FM и sound FM не объединяются в одну ветку без отдельного решения. Это сознательное ограничение branch size и verification surface.

### 8.4. Запрет на “почти working” fallback

Нельзя вводить режим, в котором encrypted playback может незаметно уйти в open/debug path. Если путь небезопасен, он должен быть явно отдельным режимом и иметь отдельную state machine.

### 8.5. Запрет на giant branches

Рабочая дисциплина веток:

- зелёная зона: `60k–120k`;
- жёлтая зона: `120k–180k`;
- красная зона: `180k–220k`;
- после `220k` — handoff или разрезание задачи;
- не планировать ветки вплотную к техническому потолку `258000`.

## 9. Формат обязательного обновления после каждой ветки

Каждая завершённая ветка обязана обновить этот документ в следующем формате:

### 9.1. Заголовок обновления

- дата;
- branch/task id;
- исполнитель;
- итоговый статус: `REVIEW` или `DONE`.

### 9.2. Что изменилось

Кратко перечислить:

- какие файлы изменены;
- какие companion-specs обновлены;
- какие команды проверки запускались;
- какие артефакты созданы.

### 9.3. Evidence

Указать:

- путь к логам;
- путь к отчётам тестов;
- путь к snapshots/dumps/evidence-pack;
- краткий итог приёмки.

### 9.4. Остаточные риски

Нужно явно указать:

- что не покрыто тестами;
- какие negative cases остались;
- какие ограничения или технический долг появились.

### 9.5. Следующая рекомендуемая ветка

В конце каждого обновления нужно явно назвать следующую рекомендуемую branch-sized задачу.

## 10. Шаблон записи о завершённой ветке

Ниже — шаблон, который Codex должен копировать в конец документа после завершения каждой ветки.

```md
### [YYYY-MM-DD] <TASK-ID> — <task title>

- Статус: REVIEW | DONE
- Исполнитель: Codex
- Ветка: <branch name>
- Краткий итог: <1–3 предложения>
- Изменённые файлы: <список или путь к diff-summary>
- Проверка: <команды>
- Evidence: <пути к логам/отчётам>
- Что не покрыто: <кратко>
- Риски: <кратко>
- Следующая рекомендуемая ветка: <TASK-ID>
```

## 11. Текущее итоговое резюме

На момент этого документа проект находится в **готовности к первой реализационной ветке**, но ещё не имеет принятого implementation baseline.

Краткая формула состояния:

- архитектура: **зафиксирована**;
- secure baseline: **зафиксирован**;
- task slicing: **зафиксирован**;
- companion-spec discipline: **зафиксирована**;
- кодовая база: **не принята**;
- первая ветка: **`T00a` готова к запуску**.
