# AGENTS.md — T00b Formal companion specs freeze
## 1. Task goal

Create or refresh the baseline companion specs that define the domain objects, contracts, and invariants used by later branches.

## 2. Out of scope

- No parser or runtime implementation.
- No UI or playback code.
- No transport integration.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/CODE_STYLE.md`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `specs/objects/**`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `docs/ARCHITECTURE.md`

## 5. Deliverables

- Object spec files listed in `docs/PLAN.md` section 5.
- Consistent fields, invariants, validation rules, and versioning notes.
- Spec cross-links where needed.

## 6. Definition of Done

- All baseline specs exist.
- Spec style is consistent.
- Later tasks can cite specs instead of inventing contracts in code.

## 7. Verification

```bash
grep -R "^# " specs/objects
markdownlint specs/objects || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
