# AGENTS.md — T06e Sound FM reference path
## 1. Task goal

Create the separate sound forensic watermark reference path and connect it to the detector harness.

## 2. Out of scope

- No picture FM changes unless needed for shared evidence interfaces.
- No TMS work.
- No AES3 output.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/WatermarkPayload.md`
- `specs/objects/WatermarkEvidence.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/watermark/**`
- `src/audio/**`
- `tests/compliance/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- Sound FM reference insertion.
- Detector integration.
- Sound attack-matrix coverage.

## 6. Definition of Done

- Sound FM exists as a separate tested track and does not piggyback on picture FM assumptions.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T06e || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
