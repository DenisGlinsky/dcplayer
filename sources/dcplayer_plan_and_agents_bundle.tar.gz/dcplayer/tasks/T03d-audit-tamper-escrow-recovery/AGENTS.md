# AGENTS.md — T03d Audit, tamper, escrow, recovery
## 1. Task goal

Define and implement signed/encrypted audit semantics, tamper reactions, escrow handling, and recovery procedure support.

## 2. Out of scope

- No playout orchestration.
- No GPU work.
- No TMS features.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/SecurityEvent.md`
- `specs/objects/ProtectedApiEnvelope.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/log_client/**`
- `spb1/diag/**`
- `specs/objects/SecurityEvent.md`
- `docs/ARCHITECTURE.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/integration/security/**`

## 5. Deliverables

- Security event model.
- Tamper state transitions.
- Escrow/recovery procedure notes or simulator support.
- Protected audit export rules.

## 6. Definition of Done

- Tamper and recovery flows are explicit.
- Audit fields are stable and machine-readable.
- The design reflects local/encrypted logging, tamper, recovery, and escrow requirements.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T03d || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
