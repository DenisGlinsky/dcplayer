# AGENTS.md — T03b Pi/ZymKey server ↔ Ubuntu/TPM client contract
## 1. Task goal

Formalize the mutual-TLS secure channel contract between the Pi+ZymKey service and the Ubuntu+TPM media host.

## 2. Out of scope

- No full decrypt service implementation.
- No KDM ingest.
- No playback orchestration.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/SecureChannelContract.md`
- `specs/objects/CertificateStore.md`
- `specs/objects/TrustChain.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/host_spb1_contract/**`
- `spb1/api/**`
- `specs/objects/SecureChannelContract.md`
- `docs/ARCHITECTURE.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/integration/security/**`

## 5. Deliverables

- Mutual-TLS contract.
- Identity and ACL assumptions.
- Handshake sequence diagrams or equivalent.
- Acceptance criteria for allowed/denied handshake paths.

## 6. Definition of Done

- Handshake rules are explicit and testable.
- The contract captures server key in ZymKey, client key in TPM, cert validation, and device identity checks.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T03b || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
