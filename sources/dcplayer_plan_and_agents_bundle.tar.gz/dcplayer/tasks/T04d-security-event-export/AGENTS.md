# AGENTS.md — T04d Security event export
## 1. Task goal

Export security events to the host plane in an operationally useful but secret-safe format.

## 2. Out of scope

- No web UI.
- No schedule features.
- No unrelated logging systems.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/SecurityEvent.md`
- `specs/objects/OperatorAlert.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/log_client/**`
- `src/core/alerts/**`
- `specs/objects/SecurityEvent.md`
- `specs/objects/OperatorAlert.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/unit/**`
- `tests/integration/**`

## 5. Deliverables

- Security event export schema.
- Filtering rules for host visibility.
- Operator alert mapping.

## 6. Definition of Done

- Host receives only minimal operational data.
- Event export is deterministic and documented.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T04d || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
