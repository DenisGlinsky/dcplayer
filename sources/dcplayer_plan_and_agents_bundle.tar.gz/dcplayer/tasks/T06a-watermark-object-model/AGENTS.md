# AGENTS.md — T06a Watermark object model
## 1. Task goal

Define watermark payload, control flags, evidence format, attack matrix, and state semantics for picture and sound FM work.

## 2. Out of scope

- No GPU insertion code.
- No detector implementation beyond interfaces.
- No secure orchestration.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/WatermarkPayload.md`
- `specs/objects/WatermarkEvidence.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `specs/objects/WatermarkPayload.md`
- `specs/objects/WatermarkEvidence.md`
- `src/watermark/fm_backend_api/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- Payload spec.
- Evidence spec.
- Attack matrix notes.
- Control/state model.

## 6. Definition of Done

- Detector and inserter branches can rely on one stable object model and one attack-matrix vocabulary.

## 7. Verification

```bash
grep -R "Watermark" specs/objects src/watermark/fm_backend_api || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
