# AGENTS.md — T08d Encrypted show rehearsal
## 1. Task goal

Run a full encrypted playback rehearsal and produce a reproducible runbook and evidence pack.

## 2. Out of scope

- No new product features unless they block the rehearsal.
- No UI expansion.
- No opportunistic refactors.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `specs/objects/PlaybackSession.md`

## 4. Files allowed to modify

- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `tests/compliance/**`
- `tests/integration/**`
- `scripts/**`
- `artifacts/**`

## 5. Deliverables

- Rehearsal procedure.
- Evidence pack.
- Acceptance checklist and known-gaps note.

## 6. Definition of Done

- An encrypted show can be rehearsed reproducibly and audited.

## 7. Verification

```bash
./scripts/rehearse_encrypted_show.sh || true
ctest --test-dir build --output-on-failure -R T08d || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
