# AGENTS.md — T02b Supplemental semantics
## 1. Task goal

Define and implement supplemental package merge and override rules without expanding into playback.

## 2. Out of scope

- No decode or playout.
- No security work.
- No UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/SupplementalMergePolicy.md`
- `specs/objects/CompositionGraph.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/dcp/supplemental/**`
- `src/dcp/ov_vf_resolver/**`
- `specs/objects/SupplementalMergePolicy.md`
- `tests/fixtures/**`
- `tests/unit/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- Supplemental merge policy.
- Implementation support in resolver path.
- OV+VF+supplemental fixtures.

## 6. Definition of Done

- Supplemental merge behavior is documented and deterministic.
- Resolver output is reproducible on fixtures.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T02b || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
