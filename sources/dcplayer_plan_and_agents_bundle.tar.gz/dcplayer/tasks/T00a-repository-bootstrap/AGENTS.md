# AGENTS.md — T00a Repository bootstrap
## 1. Task goal

Set up the repository skeleton, build system, presets, scripts, and placeholder targets so later branches can work without re-laying the foundation.

## 2. Out of scope

- No DCP parsing logic.
- No security or KDM logic.
- No playback features.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/CODE_STYLE.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `CMakeLists.txt`
- `cmake/**`
- `scripts/**`
- `apps/**/CMakeLists.txt`
- `src/**/CMakeLists.txt`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- CMake project root and presets.
- Bootstrap and smoke scripts.
- Directory skeleton and placeholder targets.
- Initial build/test instructions.

## 6. Definition of Done

- Repository configures on the primary Linux target.
- Repository builds without ad-hoc manual fixes.
- Scaffold-level tests or smoke checks pass.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
./scripts/bootstrap.sh
./scripts/smoke.sh
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
