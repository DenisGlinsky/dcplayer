# AGENTS.md — T01b CPL parser
## 1. Task goal

Implement parse and validation for CPL, reels, track references, edit rate, and composition metadata.

## 2. Out of scope

- No OV/VF resolution.
- No timeline generation.
- No playback.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/CODE_STYLE.md`
- `specs/objects/CPL.md`
- `specs/objects/Reel.md`
- `specs/objects/TrackFile.md`

## 4. Files allowed to modify

- `src/dcp/cpl/**`
- `tests/fixtures/**`
- `tests/unit/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- CPL parser.
- Reel and track reference model integration.
- Negative fixtures and diagnostics.

## 6. Definition of Done

- CPL parse output is deterministic.
- Invalid structures fail clearly.
- Track references are represented in the domain model.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T01b || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
