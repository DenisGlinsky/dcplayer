# AGENTS.md — T03c ACL + protected API envelope
## 1. Task goal

Define the protected request/response envelope and authorization model for secure operations such as sign, unwrap, and decrypt.

## 2. Out of scope

- No full device firmware.
- No playback code.
- No UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/ProtectedApiEnvelope.md`
- `specs/objects/SecureChannelContract.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/host_spb1_contract/**`
- `spb1/api/**`
- `specs/objects/ProtectedApiEnvelope.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/integration/security/**`

## 5. Deliverables

- Protected API envelope spec.
- ACL and identity rules.
- Error codes and idempotency notes.

## 6. Definition of Done

- Secure operations can be added under one envelope without redefining the transport model.
- ACL checks and audit fields are explicit.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T03c || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
