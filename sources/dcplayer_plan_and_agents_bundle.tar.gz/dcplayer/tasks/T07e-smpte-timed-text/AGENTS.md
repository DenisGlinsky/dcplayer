# AGENTS.md — T07e SMPTE timed text
## 1. Task goal

Implement SMPTE Timed Text with font handling and timing/render integration.

## 2. Out of scope

- No Interop subtitle changes except shared hooks.
- No audio work.
- No TMS/UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/STATUS.md`
- `specs/objects/PlaybackTimeline.md`

## 4. Files allowed to modify

- `src/subtitles/smpte_tt/**`
- `src/playout/**`
- `tests/fixtures/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- SMPTE timed text parser.
- Font handling.
- Timing and render integration tests.

## 6. Definition of Done

- SMPTE timed text behaves deterministically on reference fixtures.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T07e || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
