# AGENTS.md — T01c dcp_probe and composition graph
## 1. Task goal

Build `dcp_probe` so it reads a DCP directory and emits a deterministic normalized composition graph.

## 2. Out of scope

- No decode or playback.
- No security logic.
- No TMS/UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/CompositionGraph.md`
- `docs/CODE_STYLE.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `apps/dcp_probe/**`
- `src/dcp/**`
- `tests/integration/**`
- `tests/fixtures/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- `apps/dcp_probe` CLI.
- Stable JSON output format.
- Interop and SMPTE integration fixtures/tests.

## 6. Definition of Done

- `dcp_probe <path>` returns deterministic JSON.
- CLI exit codes are stable.
- Integration tests cover at least one Interop and one SMPTE sample.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T01c || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
