# AGENTS.md — T08b Secure playout orchestrator
## 1. Task goal

Assemble the full secure show chain from local storage through HSM decrypt, GPU decode, GPU picture FM, and playout.

## 2. Out of scope

- No SMS/TMS work.
- No sound FM beyond already defined interfaces.
- No unrelated open-path refactors.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/PlaybackSession.md`
- `specs/objects/SecurityModuleContract.md`
- `specs/objects/WatermarkPayload.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/playout/**`
- `src/security_api/**`
- `src/video/**`
- `src/watermark/**`
- `apps/playout_service/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- Secure session orchestrator.
- Coordination between host, security module, GPU decode, and FM.
- Explicit failure handling.

## 6. Definition of Done

- Secure playback follows the fixed chain with explicit state transitions and no silent fallback.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T08b || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
