# AGENTS.md — T03e Secure time semantics
## 1. Task goal

Define secure UTC time, skew policy, timestamp rules, and show-window dependencies for the secure module.

## 2. Out of scope

- No KDM ingest implementation beyond what is required to test time semantics.
- No playback orchestration.
- No UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/SecurityModuleContract.md`
- `specs/objects/KDMValidationResult.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/**/time*`
- `spb1/api/**`
- `specs/objects/SecurityModuleContract.md`
- `specs/objects/KDMValidationResult.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/unit/**`
- `tests/integration/security/**`

## 5. Deliverables

- Secure time contract.
- Skew/drift policy.
- Negative tests for inconsistent time and show-window conditions.

## 6. Definition of Done

- Time semantics are explicit and reusable by KDM validation and audit logging.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T03e || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
