# AGENTS.md — T02a OV/VF resolver
## 1. Task goal

Resolve OV/VF dependencies and detect missing assets, broken references, and graph conflicts.

## 2. Out of scope

- No supplemental merge rules beyond what is needed to keep scope isolated.
- No timeline rendering.
- No playback.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/CompositionGraph.md`
- `specs/objects/CPL.md`
- `docs/CODE_STYLE.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/dcp/ov_vf_resolver/**`
- `tests/fixtures/**`
- `tests/unit/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- OV/VF resolver.
- Missing/conflict diagnostics.
- Effective composition graph output.

## 6. Definition of Done

- OV and VF relationships resolve on fixtures.
- Broken references produce deterministic diagnostics.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T02a || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
