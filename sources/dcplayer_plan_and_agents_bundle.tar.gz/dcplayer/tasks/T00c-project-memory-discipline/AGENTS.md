# AGENTS.md — T00c Project memory discipline
## 1. Task goal

Lock down the rules for durable project memory, handoff format, artifact naming, and task-local readsets.

## 2. Out of scope

- No product features.
- No parser or playback work.
- No infrastructure changes beyond documentation and templates.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `docs/CODE_STYLE.md`

## 4. Files allowed to modify

- `AGENTS.md`
- `tasks/**`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `docs/PLAN.md`
- `docs/CODE_STYLE.md`

## 5. Deliverables

- Documented handoff format.
- Artifact naming and storage rules.
- Task template rules for required reading sets and stop conditions.

## 6. Definition of Done

- A future branch can end with a clean reproducible handoff.
- Rules are short, explicit, and enforceable.

## 7. Verification

```bash
test -f AGENTS.md
find tasks -name AGENTS.md | sort | head
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
