# AGENTS.md — T04c Fail-closed playback state machine
## 1. Task goal

Define and implement the security-critical playback state machine with explicit denial paths and no silent fallback.

## 2. Out of scope

- No full orchestrator.
- No UI beyond operator-visible state reasons.
- No unrelated refactors.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/PlaybackSession.md`
- `specs/objects/SecurityModuleContract.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/playout/**`
- `src/security_api/**`
- `specs/objects/PlaybackSession.md`
- `docs/ARCHITECTURE.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/unit/**`
- `tests/integration/**`

## 5. Deliverables

- State machine definition.
- Explicit transition and denial rules.
- Operator-visible failure reasons.

## 6. Definition of Done

- No hidden degraded mode remains.
- Each denial path is logged and testable.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T04c || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
