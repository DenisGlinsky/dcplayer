# AGENTS.md — T09a Local SMS API
## 1. Task goal

Implement the local control API for one auditorium, including state, transport-safe commands, inventory, and alerts.

## 2. Out of scope

- No full TMS web.
- No remote multi-site features.
- No unrelated UI framework work.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/OperatorAlert.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 4. Files allowed to modify

- `apps/sms_ui/**`
- `src/core/**`
- `src/playout/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- Local SMS API.
- Play/pause/stop and state control.
- Inventory and alerts endpoints.

## 6. Definition of Done

- One auditorium can be controlled through a stable local API.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T09a || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
