# AGENTS.md — T06d Secure playback integration
## 1. Task goal

Integrate GPU picture FM into the secure encrypted show chain between decrypt handoff and playout.

## 2. Out of scope

- No sound FM.
- No TMS features.
- No open-mode orchestration changes unless required for shared interfaces.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/PlaybackSession.md`
- `specs/objects/WatermarkPayload.md`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 4. Files allowed to modify

- `src/playout/**`
- `src/video/**`
- `src/watermark/**`
- `src/security_api/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/integration/**`
- `tests/compliance/**`

## 5. Deliverables

- Integrated secure chain from decrypt handoff to playout.
- Explicit FM state propagation.
- Failure handling for unavailable or denied FM state.

## 6. Definition of Done

- Secure chain uses `HSM decrypt -> GPU decode -> GPU picture FM -> playout` with explicit state transitions.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T06d || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
