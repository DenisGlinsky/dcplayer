# AGENTS.md — T05c GPU decode contract
## 1. Task goal

Define the GPU memory ownership, handoff boundary, queueing, and synchronization model for `decrypt -> decode`.

## 2. Out of scope

- No vendor-specific backend implementation.
- No playout orchestrator.
- No watermark insertion.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/IMPLEMENT.md`
- `docs/STATUS.md`
- `specs/objects/PlaybackSession.md`

## 4. Files allowed to modify

- `src/video/j2k_gpu_open/**`
- `src/video/**`
- `src/playout/frame_queue/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`
- `tests/unit/**`

## 5. Deliverables

- GPU decode contract.
- Queueing and synchronization model.
- Perf counters and failure surface.

## 6. Definition of Done

- Secure integration and vendor backends can target one stable GPU contract.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T05c || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
