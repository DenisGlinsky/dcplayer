# AGENTS.md — T04b KDM ingest and binding
## 1. Task goal

Implement KDM ingest, validation windows, and binding to CPL/composition identity.

## 2. Out of scope

- No secure playout orchestration.
- No GPU decode.
- No TMS UI.

## 3. Required reading set

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `specs/objects/KDMEnvelope.md`
- `specs/objects/KDMValidationResult.md`
- `specs/objects/CPL.md`
- `docs/STATUS.md`

## 4. Files allowed to modify

- `src/security_api/kdm/**`
- `src/dcp/cpl/**`
- `specs/objects/KDMEnvelope.md`
- `specs/objects/KDMValidationResult.md`
- `tests/unit/**`
- `tests/integration/**`
- `docs/STATUS.md`
- `docs/IMPLEMENT.md`

## 5. Deliverables

- KDM ingest pipeline.
- Binding rules to compositions/CPLs.
- Valid/invalid/expired/future test cases.

## 6. Definition of Done

- KDM scenarios are deterministic and fail closed.
- Binding behavior is explicit and covered by tests.

## 7. Verification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j
ctest --test-dir build --output-on-failure
ctest --test-dir build --output-on-failure -R T04b || true
```

## 8. Handoff updates

- Update `docs/STATUS.md` with what changed, what was verified, and what remains open.
- Update `docs/IMPLEMENT.md` if implementation details, file layout, or command flow changed.
- Update `docs/ARCHITECTURE.md` only if architectural decisions changed.
- Update `docs/PLAN.md` only for status, dependency, or sequencing notes relevant to this task.

## 9. Stop conditions

- Stop if completing this task requires pulling in a neighboring task from the plan.
- Stop if the task would exceed the allowed file surface without a clear justification.
- Stop if object contracts must change and the companion spec was not updated first.
- Do not perform opportunistic refactors outside the task scope.

## 10. Reporting format

At the end of the branch, report in this order:

- What was done.
- Which files changed.
- How it was verified.
- What is intentionally not covered.
- Which risks or follow-ups remain.
