# dcplayer — `docs/PLAN.md`

## 1. Purpose

This document is the branch-sized execution plan for the `dcplayer` project.

The plan is optimized for Codex work under a practical branch context budget. One branch must contain one primary engineering goal, one primary subsystem, and one acceptance surface. Durable project memory must live in repository files, not in chat history.

## 2. Fixed architectural constraints

### 2.1 Product shape

The project is a theater-oriented DCP playback system with two planes:

- **host-plane**: ingest, verify, storage, asset graph, CPL/OV/VF resolution, SMS/TMS, observability, tooling, open-content playback, orchestration;
- **secure-plane**: HSM/RTC service, device identity, certificate handling, KDM gating, secure clock semantics, signed audit trail, encrypted-show control path.

### 2.2 Secure playback chain

For the secure show path the working chain is fixed as:

`local storage -> HSM decrypt service -> GPU decode -> GPU picture FM -> playout`

This chain must be treated as the reference integration path for encrypted playback. The host side may still support open-content and debug/lab paths, but these are not allowed to silently replace the secure show path.

### 2.3 Secure control-plane design input

The project must embed the secure control-plane assumptions from the Raspberry Pi + ZymKey + TPM2 note:

- Raspberry Pi + ZymKey acts as a TLS server with the private key retained inside ZymKey;
- Ubuntu media server uses a client private key inside TPM2 for mutual-TLS client authentication;
- certificate validation includes CA chain verification and revocation handling;
- access is controlled by ACL and authenticated device identity;
- operations are logged locally and into a protected encrypted audit trail;
- tamper, recovery, escrow, time discipline, jump-host, MFA, and RBAC are part of the operational baseline;
- acceptance tests include mutual-TLS handshake control, sign/verify, ACL denial, tamper response, and recovery.

These requirements inform tasks `T03b`, `T03c`, `T03d`, `T03e`, and the later secure orchestration tasks.

### 2.4 Audio roadmap

The audio roadmap is fixed in two stages:

- **Stage A**: internal PCM engine with label-driven routing and timeline synchronization;
- **Stage B**: 24-bit AES3 output adapter.

### 2.5 Forensic watermark roadmap

Picture forensic watermarking is part of the secure show path. Sound forensic watermarking is a separate track and must not be merged into picture watermark implementation branches.

## 3. Branch budget policy

The project will use the following branch budget policy for Codex:

- **target zone**: 60k–120k tokens;
- **yellow zone**: 120k–180k tokens;
- **red zone**: above 180k tokens, split unless there is a strong reason not to;
- **hard stop**: above 220k tokens, open a new branch.

These numbers are internal working limits, not product requirements.

## 4. Project memory discipline

### 4.1 Durable memory files

Codex must treat these files as durable project memory:

- `AGENTS.md`
- `docs/PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/IMPLEMENT.md`
- `docs/CODE_STYLE.md`
- `docs/STATUS.md`
- `specs/objects/*.md`

### 4.2 Task-local reading rule

Each task-specific `AGENTS.md` must specify a **Required reading set** of at most 5–7 files. Do not instruct Codex to reread the whole repository.

### 4.3 Mandatory handoff

Every finished branch must update:

- `docs/STATUS.md`
- `docs/PLAN.md` (status/dependency notes only, unless the plan itself changes)
- `docs/IMPLEMENT.md` or `docs/ARCHITECTURE.md` if implementation or architecture changed
- task-local notes or artifacts produced by the branch

### 4.4 Spec-first rule

If a task changes an object contract, validation invariant, state machine, or external interface, the relevant companion spec must be updated before or together with the implementation.

## 5. Companion specs baseline

The companion specs baseline for the branch-sized plan is:

- `specs/objects/AssetMap.md`
- `specs/objects/PKL.md`
- `specs/objects/CPL.md`
- `specs/objects/Reel.md`
- `specs/objects/TrackFile.md`
- `specs/objects/CompositionGraph.md`
- `specs/objects/PlaybackTimeline.md`
- `specs/objects/SupplementalMergePolicy.md`
- `specs/objects/CertificateStore.md`
- `specs/objects/TrustChain.md`
- `specs/objects/SecureChannelContract.md`
- `specs/objects/ProtectedApiEnvelope.md`
- `specs/objects/SecurityModuleContract.md`
- `specs/objects/KDMEnvelope.md`
- `specs/objects/KDMValidationResult.md`
- `specs/objects/SecurityEvent.md`
- `specs/objects/WatermarkPayload.md`
- `specs/objects/WatermarkEvidence.md`
- `specs/objects/PlaybackSession.md`
- `specs/objects/FaultMatrix.md`
- `specs/objects/OperatorAlert.md`
- `specs/objects/ScheduleEntry.md`

## 6. Execution phases and branch-sized tasks

---

## Phase A — Foundation

### T00a — Repository bootstrap
**Goal**
Set up repository structure, CMake, presets, scripts, placeholder targets, and branch handoff skeletons.

**Primary outputs**
- root build files;
- bootstrap and smoke scripts;
- empty but valid target structure;
- directory skeleton consistent with the architecture.

**Depends on**
- none.

**DoD**
- repository configures and builds;
- `ctest` runs successfully on the scaffold;
- scripts for bootstrap and smoke exist and are documented.

### T00b — Formal companion specs freeze
**Goal**
Write or refresh the formal companion specs baseline used by all later tasks.

**Primary outputs**
- object specs with fields, invariants, validation rules, serialization notes, and versioning notes.

**Depends on**
- `T00a`.

**DoD**
- all baseline specs from section 5 exist;
- spec naming and style are consistent;
- no implementation logic is hidden only in code.

### T00c — Project memory discipline
**Goal**
Lock down status updates, artifact locations, handoff format, and the rule for task-local readsets.

**Primary outputs**
- durable-memory policy;
- handoff format;
- artifact naming rules;
- task template policy.

**Depends on**
- `T00a`.

**DoD**
- Codex can finish a branch and leave a reproducible handoff without relying on chat history.

---

## Phase B — DCP domain model

### T01a — ASSETMAP + PKL parser
**Goal**
Implement parse and validation for `ASSETMAP` and `PKL`.

**Primary outputs**
- normalized domain models;
- valid/invalid fixtures;
- unit coverage for structural validation.

**Depends on**
- `T00a`, `T00b`.

**DoD**
- parser handles valid fixtures;
- invalid fixtures fail with deterministic diagnostics;
- internal model is stable enough for later CPL linking.

### T01b — CPL parser
**Goal**
Implement parse and validation for `CPL`, reels, track references, edit rate, and composition metadata.

**Primary outputs**
- normalized `CPL` domain object;
- negative fixtures;
- validation diagnostics.

**Depends on**
- `T01a`.

**DoD**
- parser yields deterministic AST/domain output;
- negative cases fail clearly;
- reel and track references are represented in the domain model.

### T01c — `dcp_probe` and composition graph
**Goal**
Create a CLI that reads a DCP directory and emits a normalized composition graph.

**Primary outputs**
- `apps/dcp_probe`;
- deterministic JSON output;
- integration tests on Interop and SMPTE samples.

**Depends on**
- `T01a`, `T01b`.

**DoD**
- `dcp_probe <path>` produces deterministic machine-readable JSON;
- exit codes and diagnostics are stable.

---

## Phase C — Resolver and timeline

### T02a — OV/VF resolver
**Goal**
Resolve OV/VF dependencies and detect broken references, missing assets, and graph conflicts.

**Primary outputs**
- resolver;
- diagnostics for missing or conflicting dependencies;
- effective composition graph.

**Depends on**
- `T01c`.

**DoD**
- OV and VF relationships are resolved correctly on fixtures;
- resolver reports actionable diagnostics.

### T02b — Supplemental semantics
**Goal**
Define and implement merge/override rules for supplemental packages.

**Primary outputs**
- supplemental merge policy;
- resolver support for supplemental content;
- test fixtures and diagnostics.

**Depends on**
- `T02a`.

**DoD**
- OV + VF + supplemental dry-runs behave deterministically;
- merge rules are documented and testable.

### T02c — Dry-run playback timeline
**Goal**
Build a playback timeline by reel without doing decode or playout.

**Primary outputs**
- machine-readable timeline dump;
- effective durations for picture, audio, and text tracks;
- timeline validation diagnostics.

**Depends on**
- `T02a`, `T02b`.

**DoD**
- timeline generation is deterministic;
- timeline output is suitable as input to playback orchestration.

---

## Phase D — Security control plane

### T03a — PKI and trust store baseline
**Goal**
Define and implement certificate store, chain validation, trust anchors, and revocation model.

**Primary outputs**
- certificate store object model;
- trust chain validation rules;
- CRL/OCSP contract.

**Depends on**
- `T00b`.

**DoD**
- trust store can import and validate expected chains;
- revocation model is explicit and testable.

### T03b — Pi/ZymKey server ↔ Ubuntu/TPM client contract
**Goal**
Formalize the mutual-TLS contract between the secure service and the media host.

**Primary outputs**
- secure channel contract;
- identity and device-authorization model;
- handshake sequence diagrams and acceptance criteria.

**Depends on**
- `T03a`.

**DoD**
- sequence diagrams and API assumptions are explicit;
- simulator-level handshake rules are testable;
- the design reflects the Pi/ZymKey + TPM2 note.

### T03c — ACL + protected API envelope
**Goal**
Define the protected request/response envelope for authenticated secure operations such as sign, unwrap, and decrypt.

**Primary outputs**
- protected API envelope;
- ACL model;
- error model and idempotency rules.

**Depends on**
- `T03b`.

**DoD**
- request identity, authorization, and audit fields are explicit;
- secure operations can be added without redefining the transport model.

### T03d — Audit, tamper, escrow, recovery
**Goal**
Define signed/encrypted audit semantics, tamper reactions, escrow rules, and recovery procedures.

**Primary outputs**
- security event model;
- tamper state transitions;
- recovery/escrow operator procedure notes;
- export contract for protected audit evidence.

**Depends on**
- `T03b`, `T03c`.

**DoD**
- tamper and recovery semantics are explicit;
- audit trail fields are stable and machine-readable;
- the design reflects the operational requirements from the Pi/ZymKey + TPM2 note.

### T03e — Secure time semantics
**Goal**
Define UTC, skew policy, timestamp semantics, and show-window dependencies for the secure module.

**Primary outputs**
- secure time contract;
- skew and drift policy;
- negative test scenarios for invalid or inconsistent time.

**Depends on**
- `T03a`, `T03d`.

**DoD**
- secure time behavior is explicit;
- KDM and log timestamps have well-defined semantics.

---

## Phase E — KDM and security module behavior

### T04a — `ISecurityModule` + simulator
**Goal**
Create the host-side security module interface and a non-production simulator.

**Primary outputs**
- host-side interface;
- simulator backend;
- stub methods for time, certs, KDM, FM state, log collection, playback state.

**Depends on**
- `T03c`, `T03e`.

**DoD**
- host code can use the interface without knowing implementation details;
- simulator supports contract testing.

### T04b — KDM ingest and binding
**Goal**
Implement KDM ingest, validation window checks, and binding to compositions/CPLs.

**Primary outputs**
- KDM import pipeline;
- association with composition identity;
- valid/invalid/expired/future test cases.

**Depends on**
- `T04a`.

**DoD**
- KDM scenarios are deterministic and fail closed;
- binding rules are explicit.

### T04c — Fail-closed playback state machine
**Goal**
Define the security-critical playback state machine with no silent fallback.

**Primary outputs**
- state machine definition;
- transition rules;
- operator-visible failure reasons.

**Depends on**
- `T04a`, `T04b`.

**DoD**
- no degraded hidden mode;
- every denial path is explicit and auditable.

### T04d — Security event export
**Goal**
Export operational security events to the host plane without exposing secrets.

**Primary outputs**
- export schema;
- event filtering rules;
- operational summaries for SMS/TMS.

**Depends on**
- `T03d`, `T04c`.

**DoD**
- host gets only the minimal operational data it needs;
- event export is deterministic and documented.

---

## Phase F — Decode backend stack

### T05a — J2K backend abstraction
**Goal**
Define the common backend interface for CPU and GPU JPEG 2000 decode.

**Primary outputs**
- `J2KBackend` contract;
- frame surface model;
- queueing, counters, and error model.

**Depends on**
- `T02c`.

**DoD**
- playout core can target CPU or GPU backends through one interface.

### T05b — CPU reference decoder
**Goal**
Create a deterministic CPU baseline decoder used for validation and fallback.

**Primary outputs**
- CPU decode path;
- baseline comparison outputs;
- deterministic regression fixtures.

**Depends on**
- `T05a`.

**DoD**
- CPU path is stable enough to serve as the reference implementation.

### T05c — GPU decode contract
**Goal**
Define memory ownership, handoff boundary, queueing, and synchronization for `decrypt -> decode`.

**Primary outputs**
- GPU decode contract;
- queueing model;
- sync primitives and perf counters.

**Depends on**
- `T05a`.

**DoD**
- secure integration work can target a stable GPU contract.

### T05d — NVIDIA backend
**Goal**
Implement the production GPU decode backend for NVIDIA.

**Primary outputs**
- NVIDIA decode backend;
- metrics hooks;
- smoke playback on reference samples.

**Depends on**
- `T05c`, `T05b`.

**DoD**
- GPU decode works on the reference hardware target;
- metrics and diagnostics are available.

---

## Phase G — Forensic watermark

### T06a — Watermark object model
**Goal**
Define payload, control flags, evidence model, and attack matrix for forensic watermarking.

**Primary outputs**
- watermark payload spec;
- evidence model;
- attack matrix;
- control/state semantics.

**Depends on**
- `T00b`.

**DoD**
- detector and inserter can rely on one payload/evidence contract.

### T06b — Detector harness
**Goal**
Create an offline harness that scores extractability after controlled degradations.

**Primary outputs**
- harness;
- attack corpus policy;
- scoring and reporting format.

**Depends on**
- `T06a`.

**DoD**
- “100% identification” is translated into an explicit approved attack matrix.

### T06c — GPU picture FM prototype
**Goal**
Implement picture watermark insertion on the GPU path.

**Primary outputs**
- GPU watermark insertion path;
- state logging;
- integration tests with detector harness.

**Depends on**
- `T05d`, `T06b`.

**DoD**
- picture FM is inserted on the GPU path and observable in logs and detector results.

### T06d — Secure playback integration
**Goal**
Integrate GPU picture FM into the secure encrypted show path.

**Primary outputs**
- integrated secure chain from decrypt handoff to playout;
- state propagation;
- failure handling for unavailable FM state.

**Depends on**
- `T04c`, `T05d`, `T06c`.

**DoD**
- the secure chain uses `HSM decrypt -> GPU decode -> GPU picture FM -> playout`.

### T06e — Sound FM reference path
**Goal**
Create a separate sound watermark reference implementation and connect it to the detector harness.

**Primary outputs**
- sound FM reference insertion;
- detector integration;
- attack-matrix coverage for sound.

**Depends on**
- `T06b`.

**DoD**
- sound FM exists as a separate track with its own tests and evidence.

---

## Phase H — Audio and subtitles

### T07a — PCM engine + channel routing
**Goal**
Implement the multichannel PCM engine and label-driven routing.

**Primary outputs**
- PCM engine;
- channel router;
- routing validation fixtures.

**Depends on**
- `T02c`.

**DoD**
- no hardcoded “magic channel order” assumptions remain in the routing path.

### T07b — Audio clock and sync stabilization
**Goal**
Stabilize sync between audio output and show timeline.

**Primary outputs**
- audio clock model;
- drift handling;
- synchronization tests.

**Depends on**
- `T07a`, `T08a`.

**DoD**
- audio remains synchronized under expected load.

### T07c — AES3 adapter
**Goal**
Implement the 24-bit AES3 output adapter as a dedicated subsystem.

**Primary outputs**
- device abstraction;
- AES3 output contract;
- loopback or integration tests.

**Depends on**
- `T07a`.

**DoD**
- AES3 output path is isolated, testable, and documented.

### T07d — Interop subtitles
**Goal**
Implement Interop subtitle/subpicture support.

**Primary outputs**
- parser;
- timing integration;
- render integration.

**Depends on**
- `T02c`, `T08a`.

**DoD**
- Interop subtitles are displayed with correct timing on reference fixtures.

### T07e — SMPTE timed text
**Goal**
Implement SMPTE Timed Text with fonts and timing integration.

**Primary outputs**
- parser;
- font handling;
- render integration.

**Depends on**
- `T02c`, `T08a`.

**DoD**
- SMPTE timed text behaves deterministically on reference fixtures.

---

## Phase I — Playback orchestration

### T08a — Open playout orchestrator
**Goal**
Build the open-content playout path used for baseline testing and development.

**Primary outputs**
- local playout orchestrator;
- metrics and logging;
- stable timeline-driven session control.

**Depends on**
- `T02c`, `T05b`.

**DoD**
- open DCP playback is reproducible and observable.

### T08b — Secure playout orchestrator
**Goal**
Assemble the full secure show chain:
`local storage -> HSM decrypt service -> GPU decode -> GPU picture FM -> playout`

**Primary outputs**
- secure session orchestration;
- coordination between host, security module, GPU decode, and FM;
- failure handling.

**Depends on**
- `T04c`, `T05d`, `T06d`.

**DoD**
- secure playback session is end-to-end orchestrated with explicit state transitions.

### T08c — Fault matrix
**Goal**
Define and implement explicit behavior for network loss, HSM denial, KDM invalidation, GPU failure, and FM unavailability.

**Primary outputs**
- fault matrix;
- operator-facing failure reasons;
- negative tests.

**Depends on**
- `T08b`.

**DoD**
- each expected fault has a defined response, log entry, and operator signal.

### T08d — Encrypted show rehearsal
**Goal**
Run a full encrypted playback rehearsal with evidence pack and reproducible runbook.

**Primary outputs**
- rehearsal procedure;
- evidence pack;
- acceptance checklist.

**Depends on**
- `T08b`, `T08c`.

**DoD**
- an encrypted show can be rehearsed reproducibly and audited.

---

## Phase J — SMS / TMS

### T09a — Local SMS API
**Goal**
Implement the local control API for one auditorium.

**Primary outputs**
- play/pause/stop and state control;
- inventory view;
- alerts endpoint.

**Depends on**
- `T08a` for open mode, later extended by `T08b` for secure mode.

**DoD**
- one auditorium can be operated through a stable local API.

### T09b — Minimal TMS web
**Goal**
Implement the minimal TMS web UI for inventory, CPL/KDM status, scheduling, alerts, and remote launch.

**Primary outputs**
- web UI;
- status dashboard;
- schedule and alert views.

**Depends on**
- `T09a`, `T04d`.

**DoD**
- operator can see missing CPL, invalid KDM, and expiring show-window alerts.

### T09c — Monitoring and operator audit
**Goal**
Unify operator logs, role model, observability, and incident export.

**Primary outputs**
- operator audit model;
- unified observability view;
- incident/export support.

**Depends on**
- `T09a`, `T09b`, `T04d`.

**DoD**
- operator-facing monitoring is coherent across playback, security, and scheduling.

## 7. Recommended execution order

Recommended initial order:

1. `T00a`
2. `T00b`
3. `T00c`
4. `T01a`
5. `T01b`
6. `T01c`
7. `T02a`
8. `T02b`
9. `T02c`
10. `T03a`
11. `T03b`
12. `T03c`
13. `T03d`
14. `T03e`
15. `T04a`
16. `T04b`
17. `T04c`
18. `T04d`
19. `T05a`
20. `T05b`
21. `T05c`
22. `T05d`
23. `T06a`
24. `T06b`
25. `T06c`
26. `T06d`
27. `T06e`
28. `T08a`
29. `T07a`
30. `T07b`
31. `T07c`
32. `T07d`
33. `T07e`
34. `T08b`
35. `T08c`
36. `T08d`
37. `T09a`
38. `T09b`
39. `T09c`

## 8. Global non-goals for the first execution wave

These items are not part of the first execution wave unless explicitly reopened in the plan:

- full DCI certification work package;
- Intel/AMD/Apple custom production GPU J2K backends;
- final production hardening of sound forensic watermark;
- broad TMS beyond minimal operational scope;
- unbounded refactoring outside the active branch-sized task.

## 9. Global acceptance gates

The first execution wave is considered structurally successful when:

- the branch-sized process is working without context loss;
- DCP ingest/graph/timeline are deterministic;
- the security control plane is formalized and testable;
- KDM gating and fail-closed behavior are explicit;
- secure show orchestration follows the fixed chain;
- picture FM works in the secure show path;
- audio, subtitles, and AES3 each exist as isolated subsystems with tests;
- SMS/TMS can surface missing assets, invalid KDM, and operator alerts.

## 10. How to use this plan

- Open one branch for one task only.
- Read only the files listed in the task-specific `AGENTS.md`.
- Do not absorb adjacent tasks just because the code is nearby.
- Update durable project memory before ending the branch.
- If the task starts to require another subsystem, stop and open a follow-up task instead.
