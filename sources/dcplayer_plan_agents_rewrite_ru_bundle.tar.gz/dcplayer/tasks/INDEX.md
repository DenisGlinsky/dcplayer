# Индекс task-specific `AGENTS.md`

## Phase A — Основание проекта

- `T00a` — Repository bootstrap → `tasks/T00a-repository-bootstrap/AGENTS.md`
- `T00b` — Formal companion specs freeze → `tasks/T00b-formal-companion-specs-freeze/AGENTS.md`
- `T00c` — Project memory discipline → `tasks/T00c-project-memory-discipline/AGENTS.md`

## Phase B — DCP domain model

- `T01a` — ASSETMAP + PKL parser → `tasks/T01a-assetmap-plus-pkl-parser/AGENTS.md`
- `T01b` — CPL parser → `tasks/T01b-cpl-parser/AGENTS.md`
- `T01c` — dcp_probe + composition graph → `tasks/T01c-dcp-probe-plus-composition-graph/AGENTS.md`

## Phase C — Resolver и timeline

- `T02a` — OV/VF resolver → `tasks/T02a-ov-vf-resolver/AGENTS.md`
- `T02b` — Supplemental semantics → `tasks/T02b-supplemental-semantics/AGENTS.md`
- `T02c` — Dry-run playback timeline → `tasks/T02c-dry-run-playback-timeline/AGENTS.md`

## Phase D — Security control plane

- `T03a` — PKI and trust store baseline → `tasks/T03a-pki-and-trust-store-baseline/AGENTS.md`
- `T03b` — Pi/ZymKey ↔ Ubuntu/TPM mutual-TLS contract → `tasks/T03b-pi-zymkey-and-ubuntu-tpm-mutual-tls-contract/AGENTS.md`
- `T03c` — ACL + protected API envelope → `tasks/T03c-acl-plus-protected-api-envelope/AGENTS.md`
- `T03d` — Audit, tamper, escrow, recovery → `tasks/T03d-audit-tamper-escrow-recovery/AGENTS.md`
- `T03e` — Secure time semantics → `tasks/T03e-secure-time-semantics/AGENTS.md`

## Phase E — KDM и security module

- `T04a` — ISecurityModule + simulator → `tasks/T04a-isecuritymodule-plus-simulator/AGENTS.md`
- `T04b` — KDM ingest and binding → `tasks/T04b-kdm-ingest-and-binding/AGENTS.md`
- `T04c` — Fail-closed playback state machine → `tasks/T04c-fail-closed-playback-state-machine/AGENTS.md`
- `T04d` — Security event export → `tasks/T04d-security-event-export/AGENTS.md`

## Phase F — Decode backend stack

- `T05a` — J2K backend abstraction → `tasks/T05a-j2k-backend-abstraction/AGENTS.md`
- `T05b` — CPU reference decoder → `tasks/T05b-cpu-reference-decoder/AGENTS.md`
- `T05c` — GPU decode contract → `tasks/T05c-gpu-decode-contract/AGENTS.md`
- `T05d` — NVIDIA backend → `tasks/T05d-nvidia-backend/AGENTS.md`

## Phase G — Forensic watermark

- `T06a` — Watermark object model → `tasks/T06a-watermark-object-model/AGENTS.md`
- `T06b` — Detector harness → `tasks/T06b-detector-harness/AGENTS.md`
- `T06c` — GPU picture FM prototype → `tasks/T06c-gpu-picture-fm-prototype/AGENTS.md`
- `T06d` — Secure playback integration → `tasks/T06d-secure-playback-integration/AGENTS.md`
- `T06e` — Sound FM reference path → `tasks/T06e-sound-fm-reference-path/AGENTS.md`

## Phase H — Audio и subtitles

- `T07a` — PCM engine + channel routing → `tasks/T07a-pcm-engine-plus-channel-routing/AGENTS.md`
- `T07b` — Audio clock and sync stabilization → `tasks/T07b-audio-clock-and-sync-stabilization/AGENTS.md`
- `T07c` — AES3 adapter → `tasks/T07c-aes3-adapter/AGENTS.md`
- `T07d` — Interop subtitles → `tasks/T07d-interop-subtitles/AGENTS.md`
- `T07e` — SMPTE timed text → `tasks/T07e-smpte-timed-text/AGENTS.md`

## Phase I — Playback orchestration

- `T08a` — Open playout orchestrator → `tasks/T08a-open-playout-orchestrator/AGENTS.md`
- `T08b` — Secure playout orchestrator → `tasks/T08b-secure-playout-orchestrator/AGENTS.md`
- `T08c` — Fault matrix → `tasks/T08c-fault-matrix/AGENTS.md`
- `T08d` — Encrypted show rehearsal → `tasks/T08d-encrypted-show-rehearsal/AGENTS.md`

## Phase J — SMS / TMS / Operations

- `T09a` — Local SMS API → `tasks/T09a-local-sms-api/AGENTS.md`
- `T09b` — Minimal TMS web → `tasks/T09b-minimal-tms-web/AGENTS.md`
- `T09c` — Monitoring and operator audit → `tasks/T09c-monitoring-and-operator-audit/AGENTS.md`
