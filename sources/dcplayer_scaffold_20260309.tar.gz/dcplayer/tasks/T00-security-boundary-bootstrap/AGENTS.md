# T00 — Security boundary bootstrap

## Цель

Заморозить базовый trust boundary проекта и поднять репозиторный scaffold, достаточный для дальнейших задач T01/T03.

## Обязательно прочитать перед правками

1. `/Users/admin/Documents/dcplayer/AGENTS.md`
2. `README.md`
3. `docs/ARCHITECTURE.md`
4. `docs/IMPLEMENT.md`
5. `docs/PLAN.md`
6. `docs/STATUS.md`
7. `specs/objects/SecurityModuleSession.md`
8. `specs/objects/PlaybackSession.md`
9. `specs/objects/SecurityLogEvent.md`

## Scope

- build/bootstrap scaffold;
- базовый `dcp_probe` shell target/CLI scaffold;
- интерфейс `ISecurityModule` и host/SPB1 contract;
- симулятор secure module;
- минимальная диагностика и logging skeleton;
- wiring для unit/integration tests.

## Deliverables

- `apps/dcp_probe` target scaffold;
- `src/security_api/**` contracts;
- `spb1/simulator/**` contracts и simulator stub;
- bootstrap/test wiring в CMake;
- deterministic stub output для probe/simulator smoke tests.

## Non-goals

- реальное воспроизведение;
- реальная криптография KDM;
- реальный TLS стек;
- GUI;
- работа с реальным железом.

## Разрешённые пути

- `apps/dcp_probe/**`
- `src/security_api/**`
- `spb1/simulator/**`
- `tests/**`
- `docs/**`
- `specs/**`
- `CMakeLists.txt`

## Required tests

- сборка на Ubuntu;
- smoke test на создание simulator session;
- smoke test на deterministic JSON/stub output `dcp_probe`;
- unit test на state machine `ISecurityModule` stub.

## Definition of Done

- код собирается;
- simulator запускается локально;
- contracts документированы и согласованы со спецификациями;
- нет хардкода секретов;
- отчёт заполнен по шаблону.

## Специальные замечания

- secure show chain не обсуждается заново; он уже заморожен;
- если появляется сомнение, что граница между host и SPB1 меняется, работу надо остановить и вынести ADR;
- сначала симулятор, потом железо.
