# T08 — AES3 + SMS/TMS minimum

## Цель

Добавить производственный аудио-выходной адаптер AES3 и минимальные функции SMS/TMS для operational use.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `specs/objects/AudioRoutingProfile.md`
5. `specs/objects/ShowScheduleEntry.md`
6. `specs/objects/PlaybackSession.md`
7. `specs/objects/SecurityLogEvent.md`

## Scope

- AES3 output adapter;
- schedule/inventory/status model;
- remote play/pause/stop minimum;
- alerts: missing CPL, missing asset, invalid/expiring KDM, watermark state.

## Deliverables

- `src/audio/aes3_adapter/**`;
- minimal SMS API;
- minimal TMS web/service layer;
- show schedule/status objects;
- operator-facing diagnostics.

## Non-goals

- большой multi-site TMS;
- advanced theater automation integrations beyond minimum;
- feature-rich UI framework work ради внешнего вида.

## Разрешённые пути

- `src/audio/aes3_adapter/**`
- `apps/sms_ui/**`
- `apps/tms_web/**`
- `src/core/**`
- `src/playout/**`
- `src/security_api/**`
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- routing tests for AES3 channel maps;
- schedule validation tests;
- alerts generation tests;
- remote control authorization tests;
- operator status snapshot test.

## Definition of Done

- есть минимально полезный SMS/TMS для одного или нескольких экранов;
- AES3 adapter документирован и покрыт тестами;
- operational alerts читаемы и машиночитаемы;
- docs/status обновлены.
