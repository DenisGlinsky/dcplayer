# T05 — Watermark API and detector harness

## Цель

Стабилизировать внутренний контракт forensic watermark subsystem, чтобы алгоритмы и ускорители можно было менять без разлома playout graph.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `specs/objects/WatermarkPayload.md`
5. `specs/objects/FrameDescriptor.md`
6. `specs/objects/AudioRoutingProfile.md`
7. `specs/objects/SecurityLogEvent.md`

## Scope

- интерфейс watermark backend;
- control model picture/audio/no-FM;
- reference backend;
- detector harness;
- attack matrix tests и baseline metrics.

## Deliverables

- `src/watermark/fm_backend_api/**` contracts;
- `src/watermark/fm_control/**` state machine;
- `src/watermark/detector_harness/**` offline extraction harness;
- regression corpus и baseline score report.

## Non-goals

- production-grade secret algorithm;
- закрытый vendor SDK внутри repo;
- secure playback integration end-to-end.

## Разрешённые пути

- `src/watermark/**`
- `src/video/**` только при необходимости для descriptor glue
- `src/audio/**` только при необходимости для routing glue
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- backend conformance tests;
- detector round-trip tests;
- attack-matrix baseline tests для picture и audio;
- state machine tests picture/audio/no-FM.

## Definition of Done

- выбранный backend можно заменить без изменения внешнего control contract;
- есть reference backend и harness;
- атаки и метрики явно зафиксированы;
- security logs фиксируют состояние marking.
