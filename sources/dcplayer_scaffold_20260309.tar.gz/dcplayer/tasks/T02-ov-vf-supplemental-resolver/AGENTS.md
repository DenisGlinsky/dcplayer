# T02 — OV/VF/supplemental resolver

## Цель

Научить систему корректно резолвить OV/VF/supplemental compositions и строить итоговую timeline-модель по reel/resource зависимостям.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `specs/objects/Reel.md`
5. `specs/objects/TrackFile.md`
6. `specs/objects/TrackResource.md`
7. `specs/objects/CompositionGraph.md`
8. `specs/objects/SupplementalBinding.md`

## Scope

- resolver OV/VF;
- supplemental binding rules;
- timeline dump по reel/resource;
- diagnostics на missing assets, conflicting edit rates, orphan resources.

## Deliverables

- код в `src/dcp/ov_vf_resolver/**` и `src/dcp/supplemental/**`;
- JSON timeline/report;
- regression fixtures на OV+VF;
- documented conflict/error taxonomy.

## Non-goals

- decode;
- show authorization;
- watermark;
- UI.

## Разрешённые пути

- `src/dcp/ov_vf_resolver/**`
- `src/dcp/supplemental/**`
- `src/dcp/cpl/**`
- `src/core/**`
- `tests/**`
- `docs/**`
- `specs/**`
- `apps/dcp_probe/**`

## Required tests

- positive tests OV+VF merge;
- negative tests на broken supplemental references;
- edit-rate conflict tests;
- orphan asset diagnostics test.

## Definition of Done

- для OV/VF итоговый graph строится детерминированно;
- система явно сообщает, какие assets взяты из OV, а какие из VF;
- diagnostics машинно-читаемы;
- object specs синхронизированы.
