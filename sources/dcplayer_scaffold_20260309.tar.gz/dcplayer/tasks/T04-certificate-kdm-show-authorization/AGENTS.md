# T04 — Certificate, KDM and show authorization

## Цель

Реализовать certificate store, KDM ingest/validation, secure time semantics и show authorization policy.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `specs/objects/CertificateRecord.md`
5. `specs/objects/KDMRecord.md`
6. `specs/objects/SecurityModuleSession.md`
7. `specs/objects/PlaybackSession.md`
8. `specs/objects/SecurityLogEvent.md`

## Scope

- certificate store model;
- KDM ingest and validation;
- show window checks;
- FM policy extraction/control;
- security log events around authorization decisions.

## Deliverables

- KDM domain objects and validation pipeline;
- authorization API between host and secure module;
- deterministic allow/deny result codes;
- tests for valid/expired/future/malformed KDM;
- status reporting for SMS/TMS consumers.

## Non-goals

- real JPEG2000 decode;
- UI polish;
- final theater automation integration.

## Разрешённые пути

- `src/security_api/**`
- `src/dcp/**` при необходимости только для связки с CPL ids
- `spb1/simulator/**`
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- valid KDM allow;
- expired KDM deny;
- future KDM deny;
- malformed KDM reject with diagnostic;
- FM policy propagation test;
- security log generation on every auth decision.

## Definition of Done

- authorization решения fail-closed;
- состояние понятно для оператора и машиночитаемо для TMS;
- secure clock участвует в policy;
- object specs и docs обновлены.
