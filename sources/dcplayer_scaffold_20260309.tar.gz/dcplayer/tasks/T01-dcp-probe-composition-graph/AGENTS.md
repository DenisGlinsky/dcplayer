# T01 — DCP probe and composition graph

## Цель

Реализовать чтение `ASSETMAP`, `PKL`, `CPL` и построение детерминированного composition graph без playout.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `specs/objects/AssetRef.md`
5. `specs/objects/AssetMap.md`
6. `specs/objects/PackingList.md`
7. `specs/objects/CompositionPlaylist.md`
8. `specs/objects/CompositionGraph.md`

## Scope

- parser для `ASSETMAP`, `PKL`, `CPL`;
- нормализованный internal graph;
- JSON inspector/reporter;
- diagnostics на broken references и schema-level ошибки.

## Deliverables

- `apps/dcp_probe` с режимом анализа пакета;
- сущности в `src/dcp/assetmap`, `src/dcp/pkl`, `src/dcp/cpl`;
- сериализация graph в JSON;
- fixtures для Interop и SMPTE samples.

## Non-goals

- decode MXF essence;
- secure mode;
- KDM parsing;
- UI.

## Разрешённые пути

- `apps/dcp_probe/**`
- `src/dcp/assetmap/**`
- `src/dcp/pkl/**`
- `src/dcp/cpl/**`
- `src/core/**`
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- unit tests на ASSETMAP/PKL/CPL parsing;
- golden test на deterministic JSON output;
- error-path tests на missing/duplicate references;
- fixtures минимум для одного Interop и одного SMPTE пакета.

## Definition of Done

- `dcp_probe <path>` выдаёт детерминированный JSON;
- broken packages дают машинно-читаемую диагностику;
- object specs актуальны;
- отчёт содержит список покрытых fixture.
