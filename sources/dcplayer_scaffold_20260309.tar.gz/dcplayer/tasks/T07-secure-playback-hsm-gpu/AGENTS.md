# T07 — Secure playback HSM -> GPU

## Цель

Собрать secure show path в фиксированной последовательности:
`local storage -> HSM decrypt service -> GPU decode -> GPU picture FM -> playout`.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `docs/LIBRARIES.md`
5. `specs/objects/PlaybackSession.md`
6. `specs/objects/SecurityModuleSession.md`
7. `specs/objects/FrameDescriptor.md`
8. `specs/objects/WatermarkPayload.md`
9. `specs/objects/SecurityLogEvent.md`

## Scope

- secure session orchestration;
- decrypt handoff contract from secure module;
- GPU decode integration;
- GPU watermark integration;
- playout gating and fail-closed behavior;
- end-to-end telemetry/security logging.

## Deliverables

- secure playback orchestrator;
- concrete data flow contracts between host and secure module;
- GPU backend adapter(s);
- secure error taxonomy and recovery policy;
- integration tests for allow/deny/fail paths.

## Non-goals

- all-vendor production GPU parity;
- final multi-auditorium TMS features;
- speculative performance micro-optimizations вне подтверждённых узких мест.

## Разрешённые пути

- `src/security_api/**`
- `src/video/**`
- `src/playout/**`
- `src/watermark/**`
- `apps/playout_service/**`
- `spb1/**`
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- secure show authorization + playback allow path;
- deny path при invalid/expired auth state;
- fail-closed path при потере secure session;
- telemetry/log test для decrypt/decode/FM stages;
- throughput smoke test на representative sample.

## Definition of Done

- цепочка decrypt -> GPU decode -> GPU FM -> playout реально собрана;
- pipeline fail-closed;
- logs отражают каждый security-critical переход;
- fallback/diagnostics описаны и проверены.

## Специальные замечания

- exact decrypt throughput является gate, а не предположением;
- clear data handling должен быть минимизирован и чётко локализован;
- если secure boundary сдвигается, нужен ADR.
