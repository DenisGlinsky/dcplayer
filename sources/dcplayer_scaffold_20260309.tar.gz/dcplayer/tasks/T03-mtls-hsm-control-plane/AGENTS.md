# T03 — mTLS HSM control plane

## Цель

Построить доверенный control plane между Ubuntu media server и Raspberry Pi + ZymKey через mutual-TLS с учётом аппаратного хранения ключей.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `docs/LIBRARIES.md`
5. `specs/objects/CertificateRecord.md`
6. `specs/objects/SecurityModuleSession.md`
7. `specs/objects/SecurityLogEvent.md`

## Scope

- TLS server/client contract;
- device identity и ACL;
- CRL/OCSP hooks;
- secure session lifecycle;
- journaling/security event transport;
- simulator-first integration path.

## Deliverables

- host-side control plane client;
- Pi-side simulator endpoint/API contract;
- certificate record model;
- session/authz state machine;
- integration tests на allow/deny flows.

## Non-goals

- реальный production deployment на железо;
- KDM semantics;
- essence decrypt throughput;
- playout.

## Разрешённые пути

- `src/security_api/**`
- `spb1/api/**`
- `spb1/simulator/**`
- `tests/**`
- `docs/**`
- `specs/**`
- `.codex/config.toml`

## Required tests

- successful mutual-TLS handshake в simulator path;
- reject path для клиента без допустимого cert/ACL;
- log emission test;
- session timeout/close test.

## Definition of Done

- session lifecycle детерминирован;
- сертификатные объекты и revocation semantics документированы;
- integration tests отражают allow/deny flows;
- выбранный TLS integration path отражён в `docs/LIBRARIES.md`.

## Специальные замечания

- предпочтительный путь на Ubuntu: OpenSSL 3 + `tpm2-openssl` provider;
- fallback: `tpm2-pkcs11`;
- на Pi допустим прямой вызов Zymbit SDK или adapter над ним;
- ключи остаются в TPM/ZymKey и не экспортируются.
