# TASKS

В этой директории каждая задача оформляется как отдельный управляемый вертикальный срез.
Для каждой задачи существует собственный `AGENTS.md`, который Codex обязан прочитать **после** корневого `AGENTS.md` и **до** начала правок.

## Общие правила для всех задач

- одна задача = один вертикальный срез;
- нельзя менять trust boundary без ADR;
- нельзя менять object contracts без обновления `specs/objects/`;
- нельзя приносить новую зависимость без обновления `docs/LIBRARIES.md`;
- нельзя заявлять compliance без отдельной матрицы соответствия и тестов;
- любой performance path обязан иметь fallback;
- все изменения сопровождаются отчётом по `docs/templates/CODEX_REPORT.md`.

## Набор задач

| Task | Каталог | Суть задачи |
|---|---|---|
| T00 | `tasks/T00-security-boundary-bootstrap` | Зафиксировать репозиторий, контракты security module и симулятор. |
| T01 | `tasks/T01-dcp-probe-composition-graph` | Читать ASSETMAP/PKL/CPL и строить детерминированный composition graph. |
| T02 | `tasks/T02-ov-vf-supplemental-resolver` | Резолвить OV/VF/supplemental и диагностировать broken references. |
| T03 | `tasks/T03-mtls-hsm-control-plane` | Поднять control plane Ubuntu/TPM ↔ Pi/ZymKey на mutual-TLS. |
| T04 | `tasks/T04-certificate-kdm-show-authorization` | Реализовать certificate/KDM policy, secure time и show authorization. |
| T05 | `tasks/T05-watermark-api-detector-harness` | Стабилизировать pluggable forensic watermark subsystem. |
| T06 | `tasks/T06-open-playback-ubuntu` | Сделать baseline Ubuntu playback path с CPU fallback. |
| T07 | `tasks/T07-secure-playback-hsm-gpu` | Собрать secure show pipeline: decrypt → GPU decode → GPU FM → playout. |
| T08 | `tasks/T08-aes3-sms-tms-minimum` | Добавить AES3 output adapter и минимум SMS/TMS. |

## Порядок работы Codex внутри задачи

1. Прочитать корневой `AGENTS.md`.
2. Прочитать `tasks/<TASK-ID>/AGENTS.md`.
3. Прочитать перечисленные там документы и companion-спецификации.
4. Выполнить только объявленный scope.
5. Подготовить отчёт строго по шаблону.

## Обязательный минимальный состав задачи

Каждый task-specific `AGENTS.md` обязан содержать:
- цель;
- must-read список;
- scope;
- deliverables;
- non-goals;
- allowed paths;
- required tests;
- definition of done;
- специальные примечания и риски.
