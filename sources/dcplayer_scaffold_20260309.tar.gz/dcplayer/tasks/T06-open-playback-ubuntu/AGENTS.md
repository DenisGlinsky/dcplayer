# T06 — Open playback on Ubuntu

## Цель

Сделать baseline playback path для открытых DCP на Ubuntu с CPU fallback и корректной синхронизацией picture/audio/subtitles.

## Обязательно прочитать перед правками

1. корневой `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/IMPLEMENT.md`
4. `docs/LIBRARIES.md`
5. `specs/objects/PlaybackSession.md`
6. `specs/objects/FrameDescriptor.md`
7. `specs/objects/AudioRoutingProfile.md`
8. `specs/objects/SubtitleCue.md`

## Scope

- MXF read path для open content;
- CPU JPEG2000 fallback;
- audio engine baseline;
- subtitle composition;
- diagnostic preview/fullscreen path under Ubuntu.

## Deliverables

- baseline playout service;
- queue/sync/timeline logic;
- OpenJPEG backend;
- ALSA/PipeWire-compatible audio output abstraction;
- performance telemetry.

## Non-goals

- secure encrypted playback;
- final projector integration;
- AES3 output;
- final GPU FM path.

## Разрешённые пути

- `src/playout/**`
- `src/video/j2k_cpu/**`
- `src/audio/pcm_engine/**`
- `src/audio/channel_router/**`
- `src/subtitles/**`
- `apps/playout_service/**`
- `tests/**`
- `docs/**`
- `specs/**`

## Required tests

- open DCP playback smoke test;
- frame ordering tests;
- A/V sync tests;
- subtitle timing tests;
- fallback path tests without GPU.

## Definition of Done

- open DCP воспроизводится на Ubuntu в baseline path;
- пропуски и reorder кадров диагностируются;
- routing и subtitle timing машинно проверяются;
- metrics/logging достаточны для последующего performance work.
