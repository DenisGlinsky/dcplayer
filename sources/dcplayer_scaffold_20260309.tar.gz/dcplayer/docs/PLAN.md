# PLAN

## 1. Планирование проекта

Проект идёт поэтапно, без спешки. Сначала фиксируются contracts и trust boundaries, затем parser/resolver, затем secure plane, затем watermark и playout.

## 2. Milestones

### M0. Документация и repo freeze
**Состояние:** выполнено на уровне scaffold.

Выходные артефакты:
- `AGENTS.md`
- `README.md`
- `docs/*.md`
- `specs/objects/*`
- `.codex/config.toml`
- repo tree

### M1. DCP graph foundation
Задачи:
- T00
- T01
- T02

Цель:
- уметь читать package metadata;
- строить composition graph;
- резолвить OV/VF/supplemental;
- диагностировать broken packages ещё до playout.

### M2. Secure control plane
Задачи:
- T03
- T04

Цель:
- mutual-TLS между Ubuntu/TPM и Pi/ZymKey;
- certificate store;
- KDM import/validation;
- secure clock;
- signed security logs;
- show authorization.

### M3. Forensic watermark foundation
Задача:
- T05

Цель:
- стабилизировать watermark contract;
- сделать reference backend;
- построить detector harness и attack matrix.

### M4. Open playback
Задача:
- T06

Цель:
- CPU fallback + baseline Ubuntu playback;
- picture/audio/subtitles sync;
- diagnostic preview and metrics.

### M5. Secure playback
Задача:
- T07

Цель:
- end-to-end secure show path:
  `local storage -> HSM decrypt service -> GPU decode -> GPU FM -> playout`.

### M6. Integrations
Задача:
- T08

Цель:
- AES3 adapter;
- minimal SMS/TMS;
- inventory/schedule/alerts;
- operational readiness.

## 3. Task sequence

| Task | Название | Цель | Зависит от |
|---|---|---|---|
| T00 | Security boundary bootstrap | Зафиксировать контракты, симуляторы и каркас проекта | M0 |
| T01 | DCP probe and composition graph | Читать ASSETMAP/PKL/CPL и строить graph | T00 |
| T02 | OV/VF/supplemental resolver | Корректный resolve reel/resource зависимостей | T01 |
| T03 | mTLS HSM control plane | Host <-> Pi/ZymKey trust channel | T00 |
| T04 | Certificate/KDM/show authorization | KDM, policy, secure time, logs | T03, T01 |
| T05 | Watermark API and detector harness | Stabilize pluggable FM subsystem | T01 |
| T06 | Open playback Ubuntu | Baseline playback path | T02 |
| T07 | Secure playback HSM -> GPU | Full secure show pipeline | T04, T05, T06 |
| T08 | AES3 + SMS/TMS minimum | Audio output and operations | T07 |

## 4. Decision gates

### DG-1. Parser quality gate
До T03/T04 должны существовать:
- deterministic JSON graph;
- fixture coverage для Interop и SMPTE;
- понятные diagnostics.

### DG-2. Secure module gate
До T07 должны существовать:
- mutual-TLS;
- secure clock;
- signed logs;
- KDM policy;
- simulator and test harness.

### DG-3. Decrypt throughput gate
До T07 нужно подтвердить, что Raspberry Pi + ZymKey sidecar удерживает требуемую производительность для secure decrypt stage либо показать эквивалентный adjacent trusted compute path без смены API.

### DG-4. Watermark robustness gate
До T07/T08 должен существовать утверждённый attack matrix и baseline detector score.

### DG-5. AES3 readiness gate
До production rollout T08 должен закрыть:
- bit depth;
- sample rate;
- channel routing;
- hardware adapter validation.

## 5. Риски и mitigation

| Риск | Вероятность | Влияние | Что делаем |
|---|---|---|---|
| Pi-side decrypt stage не держит поток | medium | high | Ранний benchmark, возможный adjacent trusted compute, без смены host API |
| Неполный coverage OV/VF/supplemental | medium | high | Task T02 с fixture corpus и жёсткой диагностикой |
| Watermark не проходит attack matrix | medium | high | Reference backend + detector harness до secure playout |
| GPU backend asymmetry между вендорами | high | medium | Стабильный `IJ2KBackend`, обязательный CPU fallback |
| Преждевременная привязка к одной web stack для TMS | medium | low | Минимум функций сначала, UI stack вторичен |
| Случайная утечка секретов в репозиторий или логи | low | critical | Guardrails, gitignore, policy, code review |

## 6. Definition of success для MVP

MVP считается достигнутым, когда есть:
- ingest + verify + local storage;
- Interop + SMPTE parsing and resolve;
- secure control plane with mutual-TLS;
- KDM-aware show authorization;
- pluggable watermark contract с baseline detector;
- open playback on Ubuntu;
- secure playback pipeline through HSM decrypt service and GPU stages;
- minimal SMS/TMS;
- documented risks and known gaps.

## 7. Что точно не делаем раньше времени

- не строим "идеальный" multi-auditorium TMS раньше basic SMS/TMS;
- не делаем одновременно все GPU backends production-grade;
- не тащим внешние GUI frameworks в real-time path;
- не объявляем compliance без матрицы испытаний.
